﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MbUnit.Framework;
using MathNet.Numerics.LinearAlgebra;


namespace Iridium.Test
{
  [TestFixture]
  public class InterpolationFixture
  {
    [Row("[10 -10 10 -10 10]","[10 -5 -10 0 10 0 -10 -5 10]")]
    [Row("[10 -10 -15 -10 10]", "[10 -2.4375 -10 -13.5 -15 -13.5 -10 -2.4375 10]")]
    [Row("[-10 -10 -15 -10 10]", "[-10	-10	-10	-12.5	-15	-13.5	-10	-2.4375	10]")]
    [Row("[10 -10 -15 -10 -10]", "[10	-2.4375	-10	-13.5	-15	-12.5	-10	-10	-10]")]
    [Row("[10 -1 100 -10 10]","[10	0.375	-1	49.5	100	45	-10	-7.5	10]")]
    [RowTest]
    public void TestHermit(string input,string expected)
    {
      Vector x = Vector.ParseMatlabString("[1 2 3 4 5]");
      Vector y = Vector.ParseMatlabString(input);
      Vector f = Vector.ParseMatlabString("[1 1.5 2 2.5 3 3.5 4 4.5 5]");
      Vector actual = Matlab.interp1(x, y, f, Interp1Type.Hermite);
      Check.Array(Vector.ParseMatlabString(expected), actual, 1e-12);
    }
  }
}
