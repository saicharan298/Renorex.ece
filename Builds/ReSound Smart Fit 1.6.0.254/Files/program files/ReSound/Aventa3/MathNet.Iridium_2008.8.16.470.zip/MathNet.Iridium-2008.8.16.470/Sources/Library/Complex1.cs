﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Globalization;
using MathNet.Numerics.Properties;

namespace MathNet.Numerics
{
  [DebuggerDisplay("{ToMatlabString()}")]
  public partial struct Complex : IEquatable<Complex>, IComparable<Complex>
  {
    /// <summary>
    /// Formats this <c>Complex</c> into a <c>string</c>.
    /// </summary>
    public string ToMatlabString()
    {
      NumberFormatInfo numberFormat = NumberFormatInfo.InvariantInfo;
      if (IsInfinity)
      {
        return "Infinity";
      }

      if (IsNaN)
      {
        return numberFormat.NaNSymbol;
      }

      if (IsReal)
      {
        return real.ToString(numberFormat);
      }

      // note: there's a difference between the negative sign and the subtraction operator!
      if (IsImaginary)
      {
        if (Number.AlmostEqual(imag, 1))
        {
          return "i";
        }

        if (Number.AlmostEqual(imag, -1))
        {
          return numberFormat.NegativeSign + "i";
        }
        return imag.ToString(numberFormat) + "i";
      }
      else
      {
        if (Number.AlmostEqual(imag, 1))
        {
          return real.ToString(numberFormat) + "+i";
        }

        if (Number.AlmostEqual(imag, -1))
        {
          return real.ToString(numberFormat) + "-i";
        }

        if (imag < 0)
        {
          return real.ToString(numberFormat) + "-"
             + (-imag).ToString(numberFormat) + "i";
        }

        return real.ToString(numberFormat) + "+" + imag.ToString(numberFormat) + "i";
      }
    }

    public static Complex ParseMatlabString(string complex)
    {
      ComplexMatlabParser parser = new ComplexMatlabParser(complex, NumberFormatInfo.InvariantInfo);
      return parser.Complex;
    }

    private sealed class ComplexMatlabParser
    {
      Complex complex;
      int cursor; // = 0;
      string source;
      NumberFormatInfo numberFormat;

      public
      ComplexMatlabParser(
          string complex,
          NumberFormatInfo numberFormat
          )
      {
        this.numberFormat = numberFormat;
        this.source = complex.Trim();
        this.complex = ScanComplex();
      }

      #region Infrastructure

      char
      Consume()
      {
        return source[cursor++];
      }

      char LookAheadCharacterOrNull
      {
        get
        {
          if (cursor >= source.Length)
          {
            return '\0';
          }

          return source[cursor];
        }
      }

      char LookAheadCharacter
      {
        get
        {
          if (cursor >= source.Length)
          {
            throw new ArgumentException(Resources.ArgumentParseComplexNumber, "complex");
          }

          return source[cursor];
        }
      }

      #endregion

      #region Scanners

      Complex
      ScanComplex()
      {
        if (source.Equals("i"))
        {
          return Complex.I;
        }

        if (source.Equals("NaN"))
        {
          return Complex.NaN;
        }

        if (source.Equals("Inf"))
        {
          return Complex.Infinity;
        }

        ScanSkipWhitespace();
        Complex complex = ScanSignedComplexNumberPart();
        ScanSkipWhitespace();

        if (IsSign(LookAheadCharacterOrNull))
        {
          complex += ScanSignedComplexNumberPart();
        }

        return complex;
      }

      Complex
      ScanSignedComplexNumberPart()
      {
        bool negativeSign = false;

        if (IsSign(LookAheadCharacterOrNull))
        {
          if (IsNegativeSign(LookAheadCharacter))
          {
            negativeSign = true;
          }

          Consume();
          ScanSkipWhitespace();
        }

        if (negativeSign)
        {
          return -ScanComplexNumberPart();
        }

        return ScanComplexNumberPart();
      }

      Complex
      ScanComplexNumberPart()
      {
        bool imaginary = false;

        if (IsI(LookAheadCharacter))
        {
          Consume();
          ScanSkipWhitespace();

          if (IsMult(LookAheadCharacterOrNull))
          {
            Consume();
          }

          ScanSkipWhitespace();
          imaginary = true;
        }

        if (!IsNumber(LookAheadCharacterOrNull) && !IsSign(LookAheadCharacterOrNull))
        {
          return new Complex(0d, 1d);
        }

        double part = ScanNumber();
        ScanSkipWhitespace();

        if (IsMult(LookAheadCharacterOrNull))
        {
          Consume();
          ScanSkipWhitespace();
        }

        if (IsI(LookAheadCharacterOrNull))
        {
          Consume();
          ScanSkipWhitespace();
          imaginary = true;
        }

        if (imaginary)
        {
          return new Complex(0d, part);
        }
        else
        {
          return new Complex(part, 0d);
        }
      }

      double
      ScanNumber()
      {
        StringBuilder sb = new StringBuilder();

        if (IsSign(LookAheadCharacter))
        {
          sb.Append(Consume());
        }

        ScanSkipWhitespace();
        ScanInteger(sb);
        ScanSkipWhitespace();

        if (IsDecimal(LookAheadCharacterOrNull))
        {
          Consume();
          sb.Append(numberFormat.NumberDecimalSeparator);
          ScanInteger(sb);
        }

        if (IsE(LookAheadCharacterOrNull))
        {
          Consume();
          sb.Append('e');

          if (IsSign(LookAheadCharacter))
          {
            sb.Append(Consume());
          }

          ScanInteger(sb);
        }

        return double.Parse(
            sb.ToString(),
            NumberStyles.AllowDecimalPoint | NumberStyles.AllowExponent | NumberStyles.AllowLeadingSign,
            numberFormat
            );
      }

      void
      ScanInteger(
          StringBuilder sb
          )
      {
        sb.Append(Consume());
        while (IsNumber(LookAheadCharacterOrNull) || IsGroup(LookAheadCharacterOrNull))
        {
          char c = Consume();
          if (!IsGroup(c))
          {
            sb.Append(c);
          }
        }
      }

      void
      ScanSkipWhitespace()
      {
        while (cursor < source.Length && !IsNotWhiteSpace(LookAheadCharacter))
        {
          Consume();
        }
      }

      #endregion

      #region Indicators

      bool
      IsNotWhiteSpace(
          char c
          )
      {
        return IsNumber(c) || IsDecimal(c) || IsE(c) || IsI(c) || IsSign(c) || IsMult(c);
      }

      static
      bool
      IsNumber(
          char c
          )
      {
        // TODO: consider using numberFormat.NativeDigits
        return c >= '0' && c <= '9';
      }

      bool
      IsDecimal(
          char c
          )
      {
        return numberFormat.NumberDecimalSeparator.Equals(c.ToString());
      }

      bool
      IsGroup(
          char c
          )
      {
        return numberFormat.NumberGroupSeparator.Equals(c.ToString());
      }

      static
      bool
      IsE(
          char c
          )
      {
        return c == 'e';
      }

      static
      bool
      IsI(
          char c
          )
      {
        return c == 'i' || c == 'j';
      }

      bool
      IsSign(
          char c
          )
      {
        return numberFormat.PositiveSign.Equals(c.ToString()) || numberFormat.NegativeSign.Equals(c.ToString());
      }

      bool
      IsNegativeSign(
          char c
          )
      {
        return numberFormat.NegativeSign.Equals(c.ToString());
      }

      static
      bool
      IsMult(
          char c
          )
      {
        return c == '*';
      }

      #endregion

      public Complex Complex
      {
        get { return complex; }
      }

      public double Real
      {
        get { return complex.real; }
      }

      public double Imaginary
      {
        get { return complex.imag; }
      }
    }



  }
}
