﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Globalization;

namespace MathNet.Numerics.LinearAlgebra
{
  [DebuggerDisplay("{ToMatlabString()}")]
  public partial class Matrix :
      IMatrix<double>,
      ICloneable
  {
    public void MultiplyInplace(IVector<double> b)
    {
      if (null == b)
      {
        throw new ArgumentNullException("B");
      }


      if (RowCount == b.Length)
      {
        for (int i = 0; i < RowCount; i++)
        {
          for (int j = 0; j < ColumnCount; j++)
          {
            this[i, j] *= b[i];
          }
        }
      }
      else if (ColumnCount == b.Length)
      {
        for (int i = 0; i < RowCount; i++)
        {
          for (int j = 0; j < ColumnCount; j++)
          {
            this[i, j] *= b[j];
          }
        }
      }
      ResetOnDemandComputations();
    }

    public string ToMatlabString()
    {
      StringBuilder sb = new StringBuilder();

      for (int i = 0; i < _rowCount; i++)
      {
        if (i == 0)
        {
          sb.Append("[");
        }
        else
        {
          sb.Append(" ;");
        }

        for (int j = 0; j < _columnCount; j++)
        {
          if (j != 0)
          {
            sb.Append(' ');
          }

          sb.Append(_data[i][j].ToString(CultureInfo.InvariantCulture));
        }

        if (i == _rowCount - 1)
        {
          sb.Append("]");
        }
        else
        {
          sb.Append("");
        }
      }

      return sb.ToString();
    }

    public static Matrix ParseMatlabString(string str)
    {
      if (object.Equals(null, str)) return null;
      str = str.Trim();
      if (!(str.StartsWith("[") && str.EndsWith("]")))
      {
        throw new FormatException("The start and end of string shall be [ and ]");
      }

      string[] strValue = str.Substring(1, str.Length - (str.EndsWith("]") ? 2 : 1)).Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
      double[][] newData = new double[strValue.Length][];
      for (int i = 0; i < strValue.Length; ++i)
      {
        string[] rowString = strValue[i].Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        double[] rowData = new double[rowString.Length];
        for (int j = 0; j < rowString.Length; ++j)
        {
          rowData[j] = double.Parse(rowString[j], CultureInfo.InvariantCulture);
        }
        newData[i] = rowData;
      }
      return new Matrix(newData);
    }
  }
}
