﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MathNet.Numerics.LinearAlgebra
{
  public class FindPeaks
  {
    public enum FindPeakType
    {
      MinPeakDistance
    }
    public int[] locs
    {
      get;
      private set;
    }
    public Vector pks
    {
      get;
      private set;
    }

    public FindPeaks(Vector x, FindPeakType peakType, int mpd)
    {
      switch (peakType)
      {
        case FindPeakType.MinPeakDistance:
          GetPeaksContIndx(x, mpd, 0, x.Length);
          break;
      }

    }

    /// <summary>
    /// This function finds peaks in data set Data whose index set is not
    /// disjoint. No data points were removed from the original set through
    /// preprocessing. Calling this function instead of getpeaks reduces
    /// execution time. 
    /// </summary>
    /// <param name="data"></param>
    /// <param name="pd"></param>
    /// <param name="th"></param>
    /// <param name="np"></param>
    private void GetPeaksContIndx(Vector data, int pd, int th, int np)
    {
      int m = 0;                  // counter for peaks found
      int L = data.Length-1;

      int j = 0;

      // Pre-allocate for speed
      pks = Vector.Zeros(np);
      locs = new int[np];

      // First, the "Pd" neighbors, on either side, of the current data point are
      // found. Then the current data point is compared with these "Pd" neighbors
      // to determine whether it is a peak.
      while ((j < L) && (m < np))
      {
        // leftmost neighbor index
        int endL = Math.Max(0, j - pd);

        // Update the leftmost neighbor index if there is a peak within
        // "Pd" neighbors of leftmost index
        if (m > 0)
        {
          int jj = Math.Min(locs[m - 1] + pd, L ); 
          if (j < jj)
          {
            j = jj;
            endL = j - pd;
          }
        }

        // rightmost neighbor index
        int endR = Math.Min(L, j + pd);

        // create neighbor data set
        Vector temp = data[slice.init(endL, endR - endL + 1, 1)];

        // set current data point to -Inf in the neighbor data set
        int aa = j-endL;

        temp[aa] = double.NegativeInfinity;

        // Compare current data point with all neighbors
        if (Matlab.all(data[j] > (temp + th)) && (j != 0) && j != L)
        {          
          pks[m] = data[j];
          locs[m] = j;
          m = m + 1;
        }

        j = j + 1;
      }

      // return all peaks found
      if (m != 0)
      {
        pks = pks[slice.init(0, m, 1)];
        locs = locs.Take(m).ToArray();
      }
      else
      {
        pks = null;
        locs = null;
      }

    }

  }
}
