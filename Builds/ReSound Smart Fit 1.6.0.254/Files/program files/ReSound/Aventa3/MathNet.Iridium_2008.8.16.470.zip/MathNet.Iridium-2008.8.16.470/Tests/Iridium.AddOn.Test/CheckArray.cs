﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MbUnit.Framework;
using MathNet.Numerics.LinearAlgebra;

namespace Iridium.Test
{
  internal static class Check
  {
    public static void Array(Vector expected, Vector result, double delta, String AssertMessageNumber)
    {
      Assert.AreEqual(expected.Length, result.Length, AssertMessageNumber + " Unexpected length");
      for (int i = 0; i < expected.Length; i++)
        Assert.AreEqual(expected[i], result[i], delta, AssertMessageNumber + " Unexpected value in the array. (Element " + i + ")");
    }

    public static void Array(ComplexMatrix expected, ComplexMatrix result, double delta)
    {
      Assert.AreEqual(expected.RowCount, result.RowCount, " Unexpected row count");
      Assert.AreEqual(expected.ColumnCount, result.ColumnCount, " Unexpected column count");
      for (int i = 0; i < expected.RowCount; i++)
      {
        for (int j = 0; j < expected.ColumnCount; j++)
        {
          Assert.AreEqual(expected[i, j].Real, result[i, j].Real, delta, string.Format(" Unexpected value in the array. (Element {0},{1})", i, j));
          Assert.AreEqual(expected[i, j].Imag, result[i, j].Imag, delta, string.Format(" Unexpected value in the array. (Element {0},{1})", i, j));
        }
      }
    }
    public static void Array(ComplexVector expected, ComplexVector result, double delta)
    {
      Assert.AreEqual(expected.Length, result.Length, "Unexpected length");
      for (int i = 0; i < expected.Length; i++)
      {
        Assert.AreEqual(expected[i].Real, result[i].Real, delta, string.Format(" Unexpected value in the array. (Element {0})", i));
        Assert.AreEqual(expected[i].Imag, result[i].Imag, delta, string.Format(" Unexpected value in the array. (Element {0})", i));
      }
    }

    public static void Array(Matrix expected, Matrix result, double delta)
    {
      if (object.Equals(null, expected))
      {
        Assert.IsNull(result);
        return;
      }
      Assert.AreEqual(expected.RowCount, result.RowCount, " Unexpected row count");
      Assert.AreEqual(expected.ColumnCount, result.ColumnCount, " Unexpected column count");
      for (int i = 0; i < expected.RowCount; i++)
      {
        for (int j = 0; j < expected.ColumnCount; j++)
        {
          Assert.AreEqual(expected[i, j], result[i, j], delta, string.Format(" Unexpected value in the array. (Element {0},{1})", i, j));
        }
      }
    }

    public static void Array(BoolVector expected, BoolVector result, String AssertMessageNumber)
    {
      Assert.AreEqual(expected.Length, result.Length, AssertMessageNumber + " Unexpected length");
      for (int i = 0; i < expected.Length; i++)
        Assert.AreEqual(expected[i], result[i], AssertMessageNumber + " Unexpected value in the array. (Element " + i + ")");
    }
    public static void Array(int[] expected, int[] result, String AssertMessageNumber)
    {
      Assert.AreEqual(expected.Length, result.Length, AssertMessageNumber + " Unexpected length");
      for (int i = 0; i < expected.Length; i++)
        Assert.AreEqual(expected[i], result[i], AssertMessageNumber + " Unexpected value in the array. (Element " + i + ")");
    }

    public static void Array(Vector expected, Vector result, double delta)
    {
      Assert.AreEqual(expected.Length, result.Length, "Unexpected length");
      for (int i = 0; i < expected.Length; i++)
        Assert.AreEqual(expected[i], result[i], delta, "Unexpected value in the array. (Element " + i + ")");
    }


  }
}
