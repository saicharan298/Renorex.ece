﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MathNet.Numerics.Interpolation.Algorithms;

namespace MathNet.Numerics.Interpolation
{
  public static partial class Interpolation
  {
    public static IInterpolationMethod CreateHermiteSpline(
      IList<double> points,
      IList<double> values)
    {
      CubicHermiteSplineInterpolation method = new CubicHermiteSplineInterpolation();
      method.Init(
          points,
          values
          );
      return method;
    }

  }
}
