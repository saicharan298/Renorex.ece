﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MathNet.Numerics.LinearAlgebra;

namespace MathNet.Numerics.Interpolation.Algorithms
{
  public partial class CubicHermiteSplineInterpolation :
     IInterpolationMethod
  {
    /// <summary>
    /// Initialize the interpolation method with the given samples.
    /// </summary>
    /// <param name="t">Points t</param>
    /// <param name="x">Values x(t)</param>        
    public
    void
    Init(
        IList<double> t,
        IList<double> x
        )
    {
      Vector h = Matlab.diff(t);
      Vector del = Matlab.diff(x) / h;
      Init(t, x, pchipslope(t, x, del));
    }

    private Vector pchipslope(IList<double> x, IList<double> y, Vector del)
    {
      List<int> k = new List<int>();
      List<int> k1 = new List<int>();
      for (int i = 0; i < del.Length - 1; i++)
      {
        if ((Math.Sign(del[i]) * Math.Sign(del[i + 1])) > 0)
        {
          k.Add(i);
          k1.Add(i + 1);
        }
      }

      Vector h = Matlab.diff(x);
      Vector hs = h[k] + h[k1];
      Vector hs3 = hs * 3;
      Vector w1 = (h[k] + hs) / hs3;
      Vector w2 = (h[k1] + hs) / hs3;
      Vector dmax = Matlab.max(Matlab.abs(del[k]), Matlab.abs(del[k1]));
      Vector dmin = Matlab.min(Matlab.abs(del[k]), Matlab.abs(del[k1]));
      Vector d = new Vector(y.Count);
      d[k1] = dmin / (w1 * (del[k] / dmax) + w2 * (del[k1] / dmax));

      d[0] = EndPoint(h[0], h[1], del[0], del[1]);
      int n = d.Length - 1;
      d[n] = EndPoint(h[n - 1], h[n - 2], del[n - 1], del[n - 2]);

      return d;
    }

    private double EndPoint(double h0, double h1, double del0, double del1)
    {
      double d = ((2 * h0 + h1) * del0 - h0 * del1) / (h0 + h1);
      if (Math.Sign(d) != Math.Sign(del0))
      {
        d = 0;
      }
      else if ((Math.Sign(del0) != Math.Sign(del1)) && (Math.Abs(d) > Math.Abs(3 * del0)))
      {
        d = 3 * del0;
      }
      return d;
    }
  }
}
