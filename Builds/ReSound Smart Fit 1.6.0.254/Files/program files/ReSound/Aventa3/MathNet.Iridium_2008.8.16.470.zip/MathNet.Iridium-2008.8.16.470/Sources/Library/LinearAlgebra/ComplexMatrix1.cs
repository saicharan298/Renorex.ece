﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using MathNet.Numerics.Properties;
using System.Globalization;


namespace MathNet.Numerics.LinearAlgebra
{
  [DebuggerDisplay("{ToMatlabString()}")]
  public partial class ComplexMatrix :
      IMatrix<Complex>,
      ICloneable
  {
    /// <summary>
    /// Generates an n-by-m matrix filled with 1.
    /// </summary>
    /// <param name="m">Number of rows = Number of columns</param>
    public static
    ComplexMatrix
    Ones(
        int n, int m
        )
    {
      return new ComplexMatrix(n, m, Complex.One);
    }

    public void resize(int m, int n)
    {
      Complex[][] newData = new Complex[m][];
      for (int i = 0; i < _rowCount; i++)
      {
        newData[i] = new Complex[n];
      }
      for (int i = 0; i < _rowCount; i++)
      {

        for (int j = 0; j < _columnCount; j++)
        {
          newData[i][j] = _data[i][j];
        }

      }
      _data = newData;
      _rowCount = m;
      _columnCount = n;

    }

    /// <summary>
    /// Gets a submatrix.
    /// </summary>
    /// <param name="r">Array of row indices.</param>        
    /// <returns>A(r(:),:)</returns>
    /// <exception cref="System.IndexOutOfRangeException">Submatrix indices.</exception>
    public ComplexMatrix GetMatrix(int[] r)
    {
      Complex[][] newData = CreateMatrixData(r.Length, ColumnCount);
      try
      {
        for (int i = 0; i < r.Length; i++)
        {
          newData[i] = _data[r[i]];
        }
      }
      catch (IndexOutOfRangeException e)
      {
        throw new IndexOutOfRangeException(Resources.ArgumentMatrixIndexOutOfRange, e);
      }

      return new ComplexMatrix(newData);
    }

    /// <summary>
    /// Construct a matrix from a real matrix by deep-copy.
    /// </summary>
    /// <param name="realMatrix">The real matrix to copy from.</param>
    public static ComplexMatrix Create(IVector<double> realVector)
    {
      int rows = 1;
      int columns = realVector.Length;
      Complex[][] newData = new Complex[rows][];

      Complex[] col = new Complex[columns];
      for (int j = 0; j < columns; j++)
      {
        col[j] = realVector[j];
      }

      newData[0] = col;

      return new ComplexMatrix(newData);
    }

    /// <summary>
    /// Negate this complex matrix.
    /// </summary>
    public Matrix Real()
    {
      double[][] newData = new double[_rowCount][];
      for (int i = 0; i < newData.Length; i++)
      {
        double[] newRow = new double[_columnCount];
        for (int j = 0; j < newRow.Length; j++)
        {
          newRow[j] = this[i, j].Real;
        }

        newData[i] = newRow;
      }

      return new Matrix(newData);
    }

    public void MultiplyInplace(IVector<Complex> b)
    {
      if (null == b)
      {
        throw new ArgumentNullException("B");
      }
      
      if (this.GetType() == typeof(TransposeComplexMatrix))
      {
        throw new ArgumentException("TransposeComplexMatrix is not supported");
      }


      if (RowCount == b.Length)
      {
        for (int i = 0; i < RowCount; i++)
        {
          for (int j = 0; j < ColumnCount; j++)
          {
            _data[i][j] *= b[i];
          }
        }
      }
      else if (ColumnCount == b.Length)
      {
        for (int i = 0; i < RowCount; i++)
        {
          for (int j = 0; j < ColumnCount; j++)
          {
            _data[i][j] *= b[j];
          }
        }
      }
      ResetOnDemandComputations();
    }

    /// <summary>
    /// Multiply a Matrix with a vector, and this is done column or row wise. The
    /// size of vector define which way it should be multiplied.      
    /// </summary>
    /// <param name="b">Vector</param>
    /// <returns>Matrix * Vector</returns>
    public void MultiplyInplace(IVector<double> b)
    {
      if (null == b)
      {
        throw new ArgumentNullException("B");
      }

      if (this.GetType() == typeof(TransposeComplexMatrix))
      {
        throw new ArgumentException("TransposeComplexMatrix is not supported");
      }

      if (RowCount == b.Length)
      {
        for (int i = 0; i < RowCount; i++)
        {
          for (int j = 0; j < ColumnCount; j++)
          {
            _data[i][j] *= b[i];
          }
        }
      }
      else if (ColumnCount == b.Length)
      {
        for (int i = 0; i < RowCount; i++)
        {
          for (int j = 0; j < ColumnCount; j++)
          {
            _data[i][j] *= b[j];
          }
        }
      }
      ResetOnDemandComputations();
    }
    /// <summary>
    /// Multiply a Matrix with a vector, and this is done column or row wise. The
    /// size of vector define which way it should be multiplied.  
    /// <remarks>This function supports TransposeComplexMatrix</remarks>
    /// </summary>
    /// <param name="b">ComplexVector</param>
    /// <returns>Matrix * Vector</returns>
    public ComplexMatrix Multiply(IVector<Complex> b)
    {
      if (null == b)
      {
        throw new ArgumentNullException("B");
      }

      Complex[][] newData = new Complex[RowCount][];
      if (RowCount == b.Length)
      {
        for (int i = 0; i < newData.Length; i++)
        {
          Complex[] rowData = new Complex[ColumnCount];
          for (int j = 0; j < rowData.Length; j++)
          {
            rowData[j] = this[i, j] * b[i];
          }
          newData[i] = rowData;
        }
      }
      else if (ColumnCount == b.Length)
      {
        for (int i = 0; i < newData.Length; i++)
        {
          Complex[] rowData = new Complex[ColumnCount];
          for (int j = 0; j < rowData.Length; j++)
          {
            rowData[j] = this[i, j] * b[j];
          }
          newData[i] = rowData;
        }
      }
      ResetOnDemandComputations();
      return new ComplexMatrix(newData);
    }

    /// <summary>
    /// Multiply a Matrix with a vector, and this is done column or row wise. The
    /// size of vector define which way it should be multiplied.
    /// <remarks>This function supports TransposeComplexMatrix</remarks>
    /// </summary>
    /// <param name="b">Vector to multiply with</param>
    /// <returns></returns>
    public ComplexMatrix Multiply(IVector<double> b)
    {
      if (null == b)
      {
        throw new ArgumentNullException("B");
      }

      Complex[][] newData = new Complex[RowCount][];
      if (RowCount == b.Length)
      {
        for (int i = 0; i < RowCount; i++)
        {
          Complex[] rowData = new Complex[ColumnCount];
          for (int j = 0; j < ColumnCount; j++)
          {
            rowData[j] = this[i, j] * b[i];
          }
          newData[i] = rowData;
        }
      }
      else if (ColumnCount == b.Length)
      {
        for (int i = 0; i < RowCount; i++)
        {
          Complex[] rowData = new Complex[ColumnCount];
          for (int j = 0; j < ColumnCount; j++)
          {
            rowData[j] = this[i, j] * b[j];
          }
          newData[i] = rowData;
        }
      }
      ResetOnDemandComputations();
      return new ComplexMatrix(newData);
    }

    /// <summary>
    /// ArrayDivide divide a Matrix with a vector, and this is done column or row wise. The
    /// size of vector define which way it should be divided.
    /// <remarks>This function supports TransposeComplexMatrix</remarks>
    /// </summary>
    /// <param name="b">Vector to divide with</param>
    /// <returns>Matrix / Vector</returns>
    public ComplexMatrix ArrayDivide(IVector<Complex> b)
    {
      Complex[][] newData = new Complex[RowCount][];
      if (RowCount == b.Length)
      {

        for (int i = 0; i < newData.Length; i++)
        {

          Complex[] newRow = new Complex[ColumnCount];
          for (int j = 0; j < newRow.Length; j++)
          {
            newRow[j] = this[i, j] / b[i];
          }

          newData[i] = newRow;
        }
      }
      else if (ColumnCount == b.Length)
      {

        for (int i = 0; i < newData.Length; i++)
        {

          Complex[] newRow = new Complex[ColumnCount];
          for (int j = 0; j < newRow.Length; j++)
          {
            newRow[j] = this[i, j] / b[j];
          }

          newData[i] = newRow;
        }
      }
      else
      {
        throw new ArgumentException("Wrong matrix and vector dimensions");
      }
      return new ComplexMatrix(newData);
    }
    /// <summary>
    /// Multiply a complex matrix with a complex column vector.
    /// </summary>
    /// <exception cref="System.ArgumentException">Matrix inner dimensions must agree.</exception>
    public static ComplexMatrix operator *(ComplexMatrix m1, ComplexVector v2)
    {
      return m1.Multiply(v2);
    }

    /// <summary>
    /// Multiply a complex matrix with a real column vector.
    /// </summary>
    /// <exception cref="System.ArgumentException">Matrix inner dimensions must agree.</exception>
    public static ComplexMatrix operator *(
        ComplexMatrix m1,
        Vector v2
        )
    {
      return m1.Multiply(v2);
    }

    public string ToMatlabString()
    {
      StringBuilder sb = new StringBuilder();

      for (int i = 0; i < _rowCount; i++)
      {
        if (i == 0)
        {
          sb.Append("[");
        }
        else
        {
          sb.Append(" ;");
        }

        for (int j = 0; j < _columnCount; j++)
        {
          if (j != 0)
          {
            sb.Append(' ');
          }

          sb.Append(this[i,j].ToMatlabString());
        }

        if (i == _rowCount - 1)
        {
          sb.Append("]");
        }
        else
        {
          sb.Append("");
        }
      }

      return sb.ToString();
    }

    public static ComplexMatrix ParseMatlabString(string str)
    {
      if (null == str) return null;
      str = str.Trim();
      if (!(str.StartsWith("[") && str.EndsWith("]")))
      {
        throw new FormatException("The start and end of string shall be [ and ]");
      }

      string[] strValue = str.Substring(1, str.Length - (str.EndsWith("]") ? 2 : 1)).Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
      Complex[][] newData = new Complex[strValue.Length][];
      for (int i = 0; i < strValue.Length; ++i)
      {
        string[] rowString = strValue[i].Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
        Complex[] rowData = new Complex[rowString.Length];
        for (int j = 0; j < rowString.Length; ++j)
        {
          rowData[j] = Complex.ParseMatlabString(rowString[j]);
        }
        newData[i] = rowData;
      }
      return new ComplexMatrix(newData);
    }


    public Matrix realATxA()
    {
      _data = Transpose();
      GetRowColumnCount(_data, out _rowCount, out _columnCount);
      double[][] newData = new double[_rowCount][];
      for (int i = 0; i < _rowCount; ++i)
      {
        Complex[] row1Data = _data[i];
        double[] rowData = new double[_rowCount];
        for (int j = 0; j < rowData.Length; ++j)
        {
          Complex[] row2Data = _data[j];
          for (int k = 0; k < row2Data.Length; ++k)
          {
            rowData[j] += row1Data[k].Real * row2Data[k].Real + row1Data[k].Imag * row2Data[k].Imag;
          }
        }
        newData[i] = rowData;
      }
      return new Matrix(newData);
    }

    public Matrix realAconjxBdT(ComplexMatrix B)
    {
      if (B.GetType() == typeof(TransposeComplexMatrix))
      {
        throw new ArgumentException("TransposeComplexMatrix is not supported");
      }

      double[][] newData = new double[_rowCount][];
      for (int i = 0; i < newData.Length; ++i)
      {
        Complex[] row1Data = _data[i];
        double[] rowData = new double[B.RowCount];
        for (int j = 0; j < rowData.Length; ++j)
        {
          Complex[] row2Data = B.GetRowVector(j);
          for (int k = 0; k < row2Data.Length; ++k)
          {
            rowData[j] += row1Data[k].Real * row2Data[k].Real + row1Data[k].Imag * row2Data[k].Imag;
          }
        }
        newData[i] = rowData;
      }
      return new Matrix(newData);
    }
    public Matrix realAconjxBdT(ComplexVector B)
    {
      return realAconjxBdT(Matlab.reshape(B, 1, B.Length));
    }
    /// <summary>
    /// Complex matrix multiplication.
    /// </summary>
    /// <param name="b">The other complex matrix.</param>
    /// <returns>
    /// Matrix ret[i,j] = sum(this[i,k] * b[k,j])
    /// </returns>
    /// <remarks>
    /// This method has the same effect as the overloaded * operator.
    /// </remarks>
    /// <seealso cref="MultiplyInplace(IMatrix&lt;Complex&gt;)"/>
    /// <seealso cref="operator * (ComplexMatrix, ComplexMatrix)"/>
    /// <exception cref="ArgumentNullException">B must not be null.</exception>
    /// <exception cref="ArgumentException">Matrix inner dimensions must agree.</exception>
    public ComplexMatrix Multiply(ComplexMatrix B)
    {
      if (B == null)
      {
        throw new ArgumentNullException("B", string.Format(Resources.ArgumentNull, "B"));
      }

      if (B.RowCount != _columnCount)
      {
        throw new ArgumentException(Resources.ArgumentMatrixSameDimensions);
      }

      if (this.GetType() == typeof(TransposeComplexMatrix) || B.GetType() == typeof(TransposeComplexMatrix))
      {
        throw new ArgumentException("TransposeComplexMatrix is not supported");
      }

      Complex[][] newData = CreateMatrixData(_rowCount, B.ColumnCount);

      for (int j = 0; j < B.ColumnCount; j++)
      {
        // caching the column for performance
        Complex[] columnB = new Complex[_columnCount];
        for (int k = 0; k < _columnCount; k++)
        {
          columnB[k] = B._data[k][j];
        }

        // making the line-to-column product
        for (int i = 0; i < _rowCount; i++)
        {
          Complex s = 0;          
          for (int k = 0; k < _columnCount; k++)
          {
            s += this[i,k] * columnB[k];
          }

          newData[i][j] = s;
        }
      }

      return new ComplexMatrix(newData);
    }

    /// <summary>
    /// Complex matrix multiplication.
    /// </summary>
    /// <param name="b">The other real matrix.</param>
    /// <returns>
    /// Matrix ret[i,j] = sum(this[i,k] * b[k,j])
    /// </returns>
    /// <remarks>
    /// This method has the same effect as the overloaded * operator.
    /// </remarks>
    /// <seealso cref="MultiplyInplace(IMatrix&lt;double&gt;)"/>
    /// <seealso cref="operator * (ComplexMatrix, Matrix)"/>
    /// <exception cref="ArgumentNullException">B must not be null.</exception>
    /// <exception cref="ArgumentException">Matrix inner dimensions must agree.</exception>
    public
    ComplexMatrix
    Multiply(
        Matrix b
        )
    {
      if (null == b)
      {
        throw new ArgumentNullException("B");
      }

      if (b.RowCount != _columnCount)
      {
        throw new ArgumentException(Resources.ArgumentMatrixSameDimensions);
      }
      if (this.GetType() == typeof(TransposeComplexMatrix))
      {
        throw new ArgumentException("TransposeComplexMatrix is not supported");
      }

      double[][] bt = Matrix.Transpose(b);

      Complex[][] newData = new Complex[RowCount][];
      for (int i = 0; i < newData.Length; i++)
      {
        Complex[] newRow = new Complex[b.ColumnCount];
        for (int j = 0; j < newRow.Length; j++)
        {
          Complex s = Complex.Zero;
          double[] columnB = bt[j];          
          for (int k = 0; k < ColumnCount; k++)
          {
            s += this[i, k] * columnB[k];
          }

          newRow[j] = s;
        }

        newData[i] = newRow;
      }

      return new ComplexMatrix(newData);
    }


  }
}
