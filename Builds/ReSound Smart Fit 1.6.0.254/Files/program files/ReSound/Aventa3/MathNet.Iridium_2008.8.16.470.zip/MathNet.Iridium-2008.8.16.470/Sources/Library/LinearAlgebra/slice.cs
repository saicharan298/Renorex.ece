﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MathNet.Numerics.LinearAlgebra
{
  public struct slice
  {

    public slice(slice sl): this(sl.start,sl.size,sl.stride)
    {
    }

    public slice(int start, int length, int stride)
    {
      this.start = start;
      this.size = length;
      this.stride = stride;      
    }    
    public int start;// { get ; private set;  }
    public int size;// { get; private set; }
    public int stride;// { get ; private set;}

    public int this[int idx]
    {
      get {
        if (idx > size || idx < 0)
          throw new ArgumentOutOfRangeException("index must be less then size and bigger than null");
        return start + idx * stride; 
      }
    }
    public static implicit operator int[](slice sl)
    {
      int[] newData = new int[sl.size];
      for (int i = 0; i < sl.size; ++i)
      {
        newData[i] = sl.start + i * sl.stride;
      }
      return newData;
    }

    public int Max()
    {
      return start + (size-1) * stride;
    }

    public override string  ToString()
    {
      StringBuilder newData = new StringBuilder("{"); 
      for (int i = 0; i < size; ++i)
      {
        if (i != 0)
        {
          newData.Append(", ");
        }
        newData.Append(start + i * stride);        
      }
      newData.Append("}");
      return newData.ToString();      
    }

    public static slice init(int a, int b, int c)
    {
      slice sl;
      sl.start = a;
      sl.size = b;
      sl.stride = c;
      return sl;
    }

  }

}
