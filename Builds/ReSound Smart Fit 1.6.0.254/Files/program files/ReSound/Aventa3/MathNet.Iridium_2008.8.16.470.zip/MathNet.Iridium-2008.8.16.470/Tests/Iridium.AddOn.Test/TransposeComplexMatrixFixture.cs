﻿using System;
using System.Collections.Generic;
using System.Text;
using MbUnit.Framework;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics;

namespace Iridium.Test
{
  [TestFixture]
  public class TransposeComplexMatrixFixture
  {
    /// <summary>
    /// Check that the size iss corect for the transposed matrix
    /// </summary>
    /// <param name="row"></param>
    /// <param name="col"></param>
    [Row(1, 1)]
    [Row(2, 3)]
    [Row(1, 10)]
    [Row(9, 1)]
    [RowTest]
    public void TestRowAndCol(int row, int col)
    {
      ComplexMatrix cm = new ComplexMatrix(row, col);
      Assert.AreEqual(row, cm.RowCount);
      Assert.AreEqual(col, cm.ColumnCount);
      TransposeComplexMatrix tcm = Matlab.transpose(cm, false);
      ComplexMatrix cm1 = cm.Transpose();
      Assert.AreEqual(cm1.RowCount, tcm.RowCount);
      Assert.AreEqual(cm1.ColumnCount, tcm.ColumnCount);
    }

    /// <summary>
    /// Test that is possible to readout the tansposed values
    /// </summary>
    /// <param name="row">Size of matrix</param>
    /// <param name="col">Size of matrix</param>
    /// <param name="conj">Conjugated</param>
    [Row(2, 3, false)]
    [Row(2, 3, true)]
    [Row(1, 1, true)]
    [Row(1, 4, true)]
    [Row(4, 1, true)]
    [RowTest]
    public void TestValue(int row, int col, bool conj)
    {
      ComplexMatrix cm = RandomComplexMatrix(row, col);

      TransposeComplexMatrix tcm = Matlab.transpose(cm, conj);
      for (int i = 0; i < row; ++i)
      {
        for (int j = 0; j < col; ++j)
        {
          Complex c = conj ? cm[i, j].Conjugate : cm[i, j];
          Assert.AreEqual(c.Real, tcm[j, i].Real);
          Assert.AreEqual(c.Imag, tcm[j, i].Imag);
        }
      }
    }

    /// <summary>
    /// Check multipy of a transposed matrix with a complex value.
    /// </summary>
    /// <param name="row">Size of matrix</param>
    /// <param name="col">Size of matrix</param>
    /// <param name="conj">Conjugated</param>
    [Row(4, 3, false)]
    [Row(4, 3, true)]
    [Row(1, 1, true)]
    [Row(1, 10, true)]
    [Row(10, 1, true)]
    [RowTest]
    public void TestMultiply(int row, int col, bool conj)
    {
      ComplexMatrix cm = RandomComplexMatrix(row, col);
      ComplexMatrix cm1 = Matlab.transpose(cm, conj) * new Complex(2, 2);
      ComplexMatrix cm2 = (conj ? cm.Transpose().Conjugate() : cm.Transpose()) * new Complex(2, 2);
      CheckComplexMatrix(cm2, cm1);
    }

    /// <summary>
    /// Check multipy of a transposed matrix with a complex matrix. (This is not supported because of optimization) 
    /// </summary>
    /// <param name="row">Size of matrix</param>
    /// <param name="col">Size of matrix</param>
    /// <param name="conj">Conjugated</param>
    [Row(3, 2, false,ExpectedException= typeof(ArgumentException))]
    [Row(3, 2, true, ExpectedException = typeof(ArgumentException))]
    [Row(1, 1, true, ExpectedException = typeof(ArgumentException))]
    [Row(1, 10, true, ExpectedException = typeof(ArgumentException))]
    [Row(10, 1, true, ExpectedException = typeof(ArgumentException))]
    [RowTest]
    public void TestMultiplyMatrix(int row, int col, bool conj)
    {
      ComplexMatrix cm = RandomComplexMatrix(row, col);
      ComplexMatrix actual = Matlab.transpose(cm,conj) * cm;
      ComplexMatrix expected = (conj ? cm.Transpose().Conjugate() : cm.Transpose()) * cm;
      CheckComplexMatrix(expected, actual);
    }

    [Row(7, 1, true)]
    [Row(1, 10, true)]
    [Row(1, 1, true)]
    [Row(2, 3,true)]
    [Row(2, 3,false)]
    [Row(240, 253, false)]
    [RowTest]
    public void TestRealMultiply(int row, int col,bool conj)
    {
      ComplexMatrix cm = RandomComplexMatrix(row, col);
      ComplexMatrix cm1 = RandomComplexMatrix(row, col);

      DateTime Start = DateTime.Now;
      Matrix Actual = Matlab.realmultiply(Matlab.transpose(cm,conj), cm1);
      TimeSpan s = DateTime.Now.Subtract(Start);
      
      Start = DateTime.Now;
      ComplexMatrix ExpectedComplex = (conj?cm.HermitianTranspose():cm.Transpose()) * cm1;
      Matrix Expected = ExpectedComplex.Real();
      TimeSpan s1 = DateTime.Now.Subtract(Start);

      Console.WriteLine("Real multiply {0} ms",s.TotalMilliseconds);
      Console.WriteLine("Multiply and the real {0} ms", s1.TotalMilliseconds);
      CheckMatrix(Expected, Actual);
    }

    //[Test]
    public void TestSpeed()
    {
      Complex[] c = new Complex[] { new Complex(2, 3), new Complex(1, -2), new Complex(-2, -3), new Complex(4, 5), new Complex(7, 4), new Complex(5, 6) };
      ComplexMatrix cm = new ComplexMatrix(c, 2);
      int loop = 1000000;
      ComplexMatrix cm1 = new ComplexMatrix(cm.Transpose());
      ComplexMatrix cm2 = new ComplexMatrix(cm.Transpose());

      DateTime start = DateTime.Now;
      for (int i = 0; i < loop; ++i)
      {
        cm1 += Matlab.transpose(cm, false) * new Complex(0.1, 0.1);
      }
      TimeSpan d = DateTime.Now.Subtract(start);

      start = DateTime.Now;
      for (int i = 0; i < loop; ++i)
      {
        cm2 += cm.Transpose() * new Complex(0.1, 0.1); ;
      }
      TimeSpan d1 = DateTime.Now.Subtract(start);
      Assert.LowerThan(d.TotalMilliseconds, d1.TotalMilliseconds);

      CollectionAssert.AreElementsEqual(Matlab.real(cm1.GetArray()[0]), Matlab.real(cm2.GetArray()[0]));
    }

    private void CheckComplexMatrix(ComplexMatrix expected, ComplexMatrix actual)
    {
      Assert.AreEqual(expected.RowCount, actual.RowCount);
      Assert.AreEqual(expected.ColumnCount, actual.ColumnCount);
      for (int i = 0; i < expected.RowCount; ++i)
      {
        for (int j = 0; j < expected.ColumnCount; ++j)
        {
          Assert.AreEqual(expected[i, j].Real, actual[i, j].Real);
          Assert.AreEqual(expected[i, j].Imag, actual[i, j].Imag);
        }
      }
      
    }
    private void CheckMatrix(Matrix expected, Matrix actual)
    {
      Assert.AreEqual(expected.RowCount, actual.RowCount);
      Assert.AreEqual(expected.ColumnCount, actual.ColumnCount);
      for (int i = 0; i < expected.RowCount; ++i)
      {
        for (int j = 0; j < expected.ColumnCount; ++j)
        {
          Assert.AreEqual(expected[i, j], actual[i, j]);
        }
      }

    }

    private ComplexMatrix RandomComplexMatrix(int row, int col)
    {
      ComplexMatrix cm = new ComplexMatrix(row, col);
      Random r = new Random(3);
      for (int i = 0; i < row; ++i)
      {
        for (int j = 0; j < col; ++j)
        {
          cm[i, j] = new Complex(r.NextDouble(), r.NextDouble());
        }
      }
      return cm;
    }
  }
}
