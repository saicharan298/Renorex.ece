#region Math.NET Iridium (LGPL) by Ruegg, Shugai
// Math.NET Iridium, part of the Math.NET Project
// http://mathnet.opensourcedotnet.info
//
// Copyright (c) 2004-2008, Christoph R�egg, http://christoph.ruegg.name
//                          Mike Shugai
// 
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published 
// by the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public 
// License along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#endregion

using System;
using System.Text;
using System.Collections.Generic;
using MathNet.Numerics.Properties;
using MathNet.Numerics.Distributions;

namespace MathNet.Numerics.LinearAlgebra
{

    /// <summary>
    /// Real vector.
    /// </summary>
    /// <remarks>
    /// The class <c>Vector</c> provides the elementary 
    /// algebraic and conversion operations.
    /// </remarks>
    [Serializable]
    public class BoolVector :        
        IList<bool>,
        ICloneable
    {


        private bool[] _data;
        private int _length;

        /// <summary>
        /// Gets dimensionality of the vector.
        /// </summary>
        public int Length
        {
            get { return _length; }
        }

        /// <summary>
        /// Gets or sets the element indexed by <c>i</c>
        /// in the <c>Vector</c>.
        /// </summary>
        /// <param name="i">Dimension index.</param>
        public bool this[int i]
        {
            get { return _data[i]; }
            set { _data[i] = value; }
        }

        public BoolVector this[slice sl]
        {
          get
          {
            if ((sl.start + sl.size * sl.stride) > _length)
            {
              throw new ArgumentException(Resources.ArgumentTooLargeForIterationLimit);
            }
            BoolVector _V = new BoolVector(sl.size);
            int idx = sl.start;
            for (int i = 0; i < sl.size; i++)
            {
              _V[i] = _data[idx];
              idx += sl.stride;
            }
            return _V; 
          }
          set
          {
            int idx = sl.start;
            for (int i = 0; i < sl.size; i++, idx += sl.stride)
            {
              _data[idx] = value[i];
            }
          }
        }
        public int CountTrue {
          get
          {
            int b = 0;
            for (int i = 0; i < Length; ++i)
            {
              b += _data[i] ? 1 : 0;
            }
            return b;
          }
        }

        public static BoolVector operator |(BoolVector a,BoolVector b)
        {
          if (a.Length != b.Length)
          {
            throw new ArgumentException("The vectors must have the same size");
          }
          bool[] newData = new bool[a.Length];
          for(int i=0;i<a.Length;++i)
          {
            newData[i] = a[i] | b[i];
          }
          return new BoolVector(newData);
        }
        public static BoolVector operator &(BoolVector a, BoolVector b)
        {
          if (a.Length != b.Length)
          {
            throw new ArgumentException("The vectors must have the same size");
          }
          bool[] newData = new bool[a.Length];
          for (int i = 0; i < a.Length; ++i)
          {
            newData[i] = a[i] & b[i];
          }
          return new BoolVector(newData);
        }


        #region Constructors and static constructive methods

        /// <summary>
        /// Constructs an n-dimensional vector of zeros.
        /// </summary>
        /// <param name="n">Dimensionality of vector.</param>
        public
        BoolVector(
            int n
            )
        {
            _length = n;
            _data = new bool[_length];
        }
              /// <summary>
        /// Constructs a vector from a 1-D array, directly using
        /// the provided array as internal data structure.
        /// </summary>
        /// <param name="components">One-dimensional array of doubles.</param>
        /// <seealso cref="Create"/>
        public
        BoolVector(
            bool[] components
            )
        {
            _length = components.Length;
            _data = components;
        }

        /// <summary>
        /// Constructs a vector from a copy of a 1-D array.
        /// </summary>
        /// <param name="components">One-dimensional array of doubles.</param>
        public static
        BoolVector
        Create(
            bool[] components
            )
        {
          if (null == components)
          {
            throw new ArgumentNullException("components");
          }

          bool[] newData = new bool[components.Length];
          components.CopyTo(newData, 0);

          return new BoolVector(newData);
        }

        #endregion

        #region Various Helpers & Infrastructure


        /// <summary>Returns a deep copy of this instance.</summary>
        public
        BoolVector
        Clone()
        {
            return Create(_data);
        }

        /// <summary>
        /// Creates an exact copy of this matrix.
        /// </summary>
        object
        ICloneable.Clone()
        {
            return Create(_data);
        }


        /// <summary>
        /// Formats this vector to a human-readable string
        /// </summary>
        public override
        string
        ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("[");

            for(int i = 0; i < _data.Length; i++)
            {
                if(i != 0)
                {
                    sb.Append(';');
                }

                sb.Append(_data[i]);
            }

            sb.Append("]");
            return sb.ToString();
        }

        #endregion

        #region IList<double> Interface Implementation

        /// <summary>
        /// Index of an element.
        /// </summary>
        int
        IList<bool>.IndexOf(
            bool item
            )
        {
            return Array.IndexOf(_data, item);
        }

        /// <summary>
        /// True if the vector contains some element.
        /// </summary>
        bool
        ICollection<bool>.Contains(
            bool item
            )
        {
            return Array.IndexOf(_data, item) >= 0;
        }

        /// <summary>
        /// Copy all elements to some array.
        /// </summary>
        void
        ICollection<bool>.CopyTo(
            bool[] array,
            int arrayIndex
            )
        {
            _data.CopyTo(array, arrayIndex);
        }

        /// <summary>
        /// Length.
        /// </summary>
        int ICollection<bool>.Count
        {
            get { return Length; }
        }

        /// <summary>
        /// Get a typed enumerator over all elements.
        /// </summary>
        IEnumerator<bool>
        IEnumerable<bool>.GetEnumerator()
        {
            return ((IEnumerable<bool>)_data).GetEnumerator();
        }

        /// <summary>
        /// Get a non-typed enumerator over all elements.
        /// </summary>
        System.Collections.IEnumerator
        System.Collections.IEnumerable.GetEnumerator()
        {
            return _data.GetEnumerator();
        }

        /// <summary>
        /// False.
        /// </summary>
        bool ICollection<bool>.IsReadOnly
        {
            get { return false; }
        }

        /// <summary>
        /// Not Supported.
        /// </summary>
        void
        ICollection<bool>.Add(
            bool item
            )
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Not Supported.
        /// </summary>
        void
        IList<bool>.Insert(
            int index,
            bool item
            )
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Not Supported.
        /// </summary>
        bool
        ICollection<bool>.Remove(
            bool item
            )
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Not Supported.
        /// </summary>
        void
        IList<bool>.RemoveAt(
            int index
            )
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Not Supported.
        /// </summary>
        void
        ICollection<bool>.Clear()
        {
            throw new NotSupportedException();
        }

        #endregion
    }
}
