﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MathNet.Numerics.LinearAlgebra
{
  public class TransposeComplexMatrix : ComplexMatrix
  {
    public TransposeComplexMatrix(ComplexMatrix v)
      : this(v, true)
    { }

    public TransposeComplexMatrix(ComplexMatrix v, bool conj)
      : base(v)
    {
      _conj = conj;
    }
    private bool _conj;

    /// <summary>
    /// Gets the number of rows.
    /// </summary>
    public override int RowCount
    {
      get { return base.ColumnCount; }
    }

    /// <summary>
    /// Gets the number of columns.
    /// </summary>
    public override int ColumnCount
    {
      get { return base.RowCount; }
    }

    /// <summary>
    /// Gets or set the element indexed by <c>(i, j)</c>
    /// in the <c>Matrix</c>.
    /// </summary>
    /// <param name="i">Row index.</param>
    /// <param name="j">Column index.</param>
    public override Complex this[int i, int j]
    {
      get
      {
        return _conj ? base[j, i].Conjugate : base[j, i];
      }

    }
  }

}
