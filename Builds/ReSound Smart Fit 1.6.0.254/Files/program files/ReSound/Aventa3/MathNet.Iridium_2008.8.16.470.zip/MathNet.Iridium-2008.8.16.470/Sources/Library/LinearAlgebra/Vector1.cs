﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using MathNet.Numerics.Properties;
using System.Globalization;

namespace MathNet.Numerics.LinearAlgebra
{
  [DebuggerDisplay("{ToMatlabString()}")]
  public partial class Vector :
      IVector<double>,
      IList<double>,
      ICloneable
  {
    public Vector()
    {
      _length = 0;
      _data = new double[_length];

    }

    public Vector this[slice sl]
    {
      get
      {
        if ((sl.start + sl.size * sl.stride) > _length)
        {
          throw new ArgumentException(Resources.ArgumentTooLargeForIterationLimit);
        }
        Vector _V = new Vector(sl.size);
        int idx = sl.start;
        for (int i = 0; i < sl.size; i++)
        {
          _V[i] = _data[idx];
          idx += sl.stride;
        }
        return _V;
      }
      set
      {
        int idx = sl.start;
        for (int i = 0; i < sl.size; i++, idx += sl.stride)
        {
          _data[idx] = value[i];
        }
      }
    }
    public Vector this[int[] index]
    {
      get
      {
        Vector _V = new Vector(index.Length);

        for (int i = 0; i < _V.Length; i++)
        {
          _V[i] = _data[index[i]];
        }
        return _V;
      }
      set
      {
        for (int i = 0; i < index.Length; i++)
        {
          _data[index[i]] = value[i];
        }
      }
    }
    public Vector this[IList<int> index]
    {
      get
      {
        Vector _V = new Vector(index.Count);

        for (int i = 0; i < _V.Length; i++)
        {
          _V[i] = _data[index[i]];
        }
        return _V;
      }
      set
      {
        for (int i = 0; i < index.Count; i++)
        {
          _data[index[i]] = value[i];
        }
      }
    }

    public double this[BoolVector bv]
    {
      /* get
       {
         Vector _V = new Vector(index.Length);

         for (int i = 0; i < _V.Length; i++)
         {
           _V[i] = _data[index[i]];
         }
         return _V;
       }*/
      set
      {
        for (int i = 0; i < bv.Length; i++)
        {
          if (bv[i])
          {
            _data[i] = value;
          }
        }
      }
    }

    public void resize(int n)
    {
      Vector v = new Vector(_data);
      _length = n;
      _data = new double[_length];
      for (int i = 0; i < Math.Min(_length, v.Length); i++)
      {
        _data[i] = v[i];
      }
    }
    public void resize(int n, double s)
    {
      Vector v = new Vector(_data);
      _length = n;
      _data = new double[_length];
      for (int i = 0; i < Math.Min(_length, v.Length); i++)
      {
        _data[i] = v[i];
      }
      for (int i = Math.Min(_length, v.Length); i < _length; i++)
      {
        _data[i] = s;
      }
    }
    private string ParseDouble(double d)
    {
      if (Double.IsPositiveInfinity(d))
      {
        return "Inf";
      }
      else if (Double.IsNegativeInfinity(d))
      {
        return "-Inf";
      }
      else if (Double.IsNaN(d))
      {
        return "NaN";
      }
      else
      {
        return d.ToString(CultureInfo.InvariantCulture);
      }
    }

    public string ToMatlabString()
    {
      StringBuilder sb = new StringBuilder();
      sb.Append("[");

      for (int i = 0; i < _data.Length; i++)
      {
        if (i != 0)
        {
          sb.Append(' ');
        }
        sb.Append(ParseDouble(_data[i]));
      }

      sb.Append("]");
      return sb.ToString();
    }

    public static Vector ParseMatlabString(string str)
    {
      if (object.Equals(null, str)) return null;
      str = str.Trim();
      if (!(str.StartsWith("[") && str.EndsWith("]")))
      {
        throw new FormatException("The start and end of string shall be [ and ]");
      }
      string[] strValue = str.Substring(1, str.Length - (str.EndsWith("];") ? 3 : 2)).Split(new char[] { ' ', ',','\t' }, StringSplitOptions.RemoveEmptyEntries);
      return new Vector(strValue.Select(s => double.Parse(s, CultureInfo.InvariantCulture)).ToArray());
    }

    /// <summary>
    /// Subtraction Operator
    /// </summary>
    public static
    Vector
    operator -(
        double scalar,
        Vector vector
        )
    {
      Vector r = new Vector(vector.Length);
      for (int i = 0; i < vector.Length; i++)
      {
        r[i] = scalar - vector[i];
      }
      return r;
    }
    public static
    Vector
    operator /(
        Vector a,
        Vector b
        )
    {
      return a.ArrayDivide(b);
    }

    public static
    Vector
    operator /(
        double a,
        Vector b
        )
    {
      double[] newData = new double[b.Length];
      for (int i = 0; i < newData.Length; ++i)
      {
        newData[i] = a / b[i];
      }
      return new Vector(newData);
    }

    /// <summary>
    /// Scalar/dot product of two vectors.
    /// </summary>
    public static
    Vector
    operator *(
        Vector u,
        Vector v
        )
    {
      return u.ArrayMultiply(v);
    }
    /// <summary>
    /// root
    /// </summary>
    public static
    Vector
    operator ^(
        Vector vector,
        double scalar
        )
    {
      Vector r = new Vector(vector.Length);
      for (int i = 0; i < vector.Length; i++)
      {
        r[i] = Math.Pow(vector[i], scalar);
      }
      return r;
    }
    public static
    Vector
    operator ^(
        double scalar,
        Vector vector
        )
    {
      Vector r = new Vector(vector.Length);
      for (int i = 0; i < vector.Length; i++)
      {
        r[i] = Math.Pow(scalar, vector[i]);
      }
      return r;
    }

    #region BoolVector operator
    public static BoolVector operator >(Vector v, double s)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] > s;
      }
      return r;
    }
    public static BoolVector operator <(Vector v, double s)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] < s;
      }
      return r;
    }
    public static BoolVector operator >(double s, Vector v)
    {
      return v < s;
    }
    public static BoolVector operator <(double s, Vector v)
    {
      return v > s;
    }
    public static BoolVector operator >(Vector v, Vector s)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] > s[i];
      }
      return r;
    }
    public static BoolVector operator <(Vector v, Vector s)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] < s[i];
      }
      return r;
    }
    public static BoolVector operator >=(Vector v, Vector s)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] >= s[i];
      }
      return r;
    }
    public static BoolVector operator <=(Vector v, Vector s)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] <= s[i];
      }
      return r;
    }

    public static BoolVector operator >=(Vector v, double s)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] >= s;
      }
      return r;
    }
    public static BoolVector operator <=(Vector v, double s)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] <= s;
      }
      return r;
    }

    public static BoolVector operator ==(Vector v, double b)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] == b;
      }
      return r;
    }
    public static BoolVector operator !=(Vector v, double b)
    {
      BoolVector r = new BoolVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i] != b;
      }
      return r;
    }

    #endregion

  }
}
