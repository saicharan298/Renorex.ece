
Math.NET Iridium
http://mathnet.opensourcedotnet.info


The solution contains two projects, the library and test of it. The library is a branch
of the MathNet.Iridium-2008.8.16.470, where I have tried to put all the added class
functionality in new files with the same name added with the number 1. The original 
files are the updated to contain partial class and some functions are comment out because
of other functionality which better match the needed behavior.

The test project uses NUnit and all new functionality is tested in MbUnit framework.

