﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MathNet.Numerics.Properties;
using System.Diagnostics;
using System.Globalization;

namespace MathNet.Numerics.LinearAlgebra
{
  [DebuggerDisplay("{ToMatlabString()}")]
  public partial class ComplexVector :
        IVector<Complex>,
        IList<Complex>,
        ICloneable
  {
    public ComplexVector this[slice sl]
    {
      get
      {
        if ((sl.start + sl.size * sl.stride) > _length)
        {
          throw new ArgumentException(Resources.ArgumentTooLargeForIterationLimit);
        }
        ComplexVector _V = new ComplexVector(sl.size);
        int idx = sl.start;
        for (int i = 0; i < sl.size; i++)
        {
          _V[i] = _data[idx];
          idx += sl.stride;
        }
        return _V;
      }
      set
      {
        int idx = sl.start;
        for (int i = 0; i < sl.size; i++, idx += sl.stride)
        {
          _data[idx] = value[i];
        }
      }
    }
    public ComplexVector this[int[] index]
    {
      get
      {
        ComplexVector _V = new ComplexVector(index.Length);
        
        for (int i = 0; i < _V.Length; i++)
        {
          _V[i] = _data[index[i]];          
        }
        return _V;
      }
      set
      {        
        for (int i = 0; i < index.Length; i++)
        {
          _data[index[i]] = value[i];
        }
      }
    }
    public void resize(int n)
    {
      ComplexVector v = new ComplexVector(_data);
      _length = n;
      _data = new Complex[_length];
      for (int i = 0; i < Math.Min(_length, v.Length); i++)
      {
        _data[i] = v[i];
      }
    }

    public static ComplexVector operator +(
        ComplexVector complexVector,
        double scalar
        )
    {
      return complexVector.Add(scalar);
    }

    /// <summary>
    /// product of two vectors.
    /// </summary>
    public static
    ComplexVector
    operator *(
        ComplexVector u,
        ComplexVector v
        )
    {
      return u.ArrayMultiply(v);
    }

    /// <summary>
    /// product of two vectors.
    /// </summary>
    public static
    ComplexVector
    operator *(
        ComplexVector u,
        Vector v
        )
    {
      return u.ArrayMultiply(v);
    }
    /// <summary>
    /// product of two vectors.
    /// </summary>
    public static
    ComplexVector
    operator *(
        Vector v,
        ComplexVector u
        )
    {
      return u.ArrayMultiply(v);
    }

    /// <summary>
    /// </summary>
    public static
    ComplexVector
    operator /(
        ComplexVector vector,
        ComplexVector b
        )
    {
      return vector.ArrayDivide(b);
    }



    public
     string
     ToMatlabString()
    {
      StringBuilder sb = new StringBuilder();
      sb.Append("[");

      for (int i = 0; i < _data.Length; i++)
      {
        if (i != 0)
        {
          sb.Append(' ');
        }

        sb.Append(_data[i].ToMatlabString());
      }

      sb.Append("]");
      return sb.ToString();
    }

    public static ComplexVector ParseMatlabString(string str)
    {
      str = str.Trim();
      if (!(str.StartsWith("[") && str.EndsWith("]")))
      {
        throw new FormatException("The start and end of string shall be [ and ]");
      }
      string[] strValue = str.Substring(1, str.Length - (str.EndsWith("];") ? 3 : 2)).Split(new char[] { ' ', ',' }, StringSplitOptions.RemoveEmptyEntries);
      return new ComplexVector(strValue.Select(s => Complex.ParseMatlabString(s)).ToArray());
    }

    public Vector Real()
    {
      Vector v = new Vector(Length);
      for (int i = 0; i < v.Length; ++i)
      {
        v[i] = this[i].Real;
      }
      return v;
    }
    public Vector Imag()
    {
      Vector v = new Vector(Length);
      for (int i = 0; i < v.Length; ++i)
      {
        v[i] = this[i].Imag;
      }
      return v;
    }

  }
}
