﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Text;
using MathNet.Numerics;
using MathNet.Numerics.Transformations;
using MathNet.Numerics.Interpolation;
using MathNet.Numerics.Interpolation.Algorithms;
//using Extreme.Mathematics.LinearAlgebra;

namespace MathNet.Numerics.LinearAlgebra
{
  static public class Matlab
  {
    public static bool any(BoolVector a)
    {
      bool res = false;
      for (int i = 0; i < a.Length && res == false; i++)
      {
        res |= a[i];
      }
      return res;
    }
    public static bool all(BoolVector a)
    {
      bool res = true;
      for (int i = 0; i < a.Length && res == true; i++)
      {
        res = res && a[i];
      }
      return res;
    }

    public static bool isempty(Vector a)
    {
      if (Object.Equals(a, null)) return true;
      return a.Length == 0;
    }

    public static int length(Vector a)
    {
      if (object.Equals(null, a)) return 0;
      return a.Length;
    }

    public static int length(ComplexVector a)
    {
      if (object.Equals(null, a)) return 0;
      return a.Length;
    }

    public static int length(Matrix a)
    {
      if (object.Equals(null, a)) return 0;
      return Math.Max(a.ColumnCount, a.RowCount);
    }

    /*
    %CIRCSHIFT Shift array circularly.
    %   B = CIRCSHIFT(A,SHIFTSIZE) circularly shifts the values in the array A
    %   by SHIFTSIZE elements. SHIFTSIZE is a vector of integer scalars where
    %   the N-th element specifies the shift amount for the N-th dimension of
    %   array A. If an element in SHIFTSIZE is positive, the values of A are
    %   shifted down (or to the right). If it is negative, the values of A
    %   are shifted up (or to the left). 
    */

    public static Vector circshift(Vector a, int SHIFTSIZE)
    {
      int _Count = -SHIFTSIZE;
      if (a.Length == 0)
        ;	// no shift
      else if (_Count < 0)
      {	// right shift
        if (a.Length < 0 - _Count)
          _Count = (int)(a.Length - (0 - _Count - a.Length) % a.Length);
        else
          _Count = (int)(a.Length + _Count);
      }
      else if (a.Length <= _Count)
      {
        _Count %= a.Length;
      }
      Vector res = new Vector(a.Length);
      for (int _Idx = 0; _Idx < a.Length; _Idx++)
      {
        res[_Idx] = a.Length - _Idx <= _Count ? a[_Idx - a.Length + _Count] : a[_Idx + _Count];
      }
      return res;
    }
    /// <summary>
    /// Flip Vector left to right
    /// </summary>
    /// <param name="v">Input vector</param>
    /// <returns>returns V flipped in the left-right direction</returns>
    public static Vector fliplr(Vector v)
    {
      Vector r = new Vector(v.Length);
      for (int i = 0, j = v.Length - 1; i < r.Length; i++, j--)
      {
        r[i] = v[j];
      }
      return r;
    }

    //vector = linspace(start, end, n)
    public static Vector linspace(double a, double b, int n)
    {
      if ((n - 1) == 0)
      {
        return new Vector(n, a);
      }
      else
      {
        Vector res = new Vector(n);
        for (int i = 0; i < res.Length; i++)
        {
          res[i] = a + (i * (b - a) / (n - 1));
        }
        return res;
      }
    }


    public static Vector ones(int n)
    {
      return Vector.Ones(n);
    }

    public static Vector valcat(Vector a, Vector b)
    {
      Vector res = new Vector(a.Length + b.Length);
      res[slice.init(0, a.Length, 1)] = a;
      res[slice.init(a.Length, b.Length, 1)] = b;
      return res;
    }

    public static ComplexVector valcat(ComplexVector a, ComplexVector b)
    {
      ComplexVector res = new ComplexVector(a.Length + b.Length);
      res[slice.init(0, a.Length, 1)] = a;
      res[slice.init(a.Length, b.Length, 1)] = b;
      return res;
    }

    public static Vector valcat(double a, Vector b)
    {
      Vector res = new Vector(1 + b.Length);
      res[0] = a;
      res[slice.init(1, b.Length, 1)] = b;
      return res;
    }

    public static double max(Vector v)
    {
      double max = double.MinValue; ;
      for (int i = 0; i < v.Length; i++)
      {
        max = Math.Max(max, v[i]);
      }
      return max;
    }

    public static Vector max(double m, Vector v)
    {
      return max(v, m);
    }

    public static Vector max(Vector v, double max)
    {
      double[] newData = new double[v.Length];
      for (int i = 0; i < v.Length; i++)
      {
        newData[i] = Math.Max(v[i], max);
      }
      return new Vector(newData);
    }
    public static Vector max(Vector a, Vector b)
    {
      Debug.Assert(a.Length == b.Length);
      Vector max = new Vector(a.Length);
      for (int i = 0; i < a.Length; i++)
      {
        max[i] = Math.Max(a[i], b[i]);
      }
      return max;
    }

    public static double min(Vector v)
    {
      Debug.Assert(v.Length > 0);
      double min = v[0];
      for (int i = 1; i < v.Length; i++)
      {
        min = Math.Min(min, v[i]);
      }
      return min;
    }
    public static Vector min(Vector a, Vector b)
    {
      Debug.Assert(a.Length == b.Length);
      Vector min = new Vector(a.Length);
      for (int i = 0; i < a.Length; i++)
      {
        min[i] = Math.Min(a[i], b[i]);
      }
      return min;
    }
    public static Vector min(double b, Vector a)
    {
      return min(a, b);
    }
    public static Vector min(Vector a, double b)
    {
      Vector min = new Vector(a.Length);
      for (int i = 0; i < a.Length; i++)
      {
        min[i] = Math.Min(a[i], b);
      }
      return min;
    }

    public static int maxi(Vector v)
    {
      int index = 0;
      double max = double.MinValue;
      for (int i = 0; i < v.Length; i++)
      {
        if (max < v[i])
        {
          max = v[i];
          index = i;
        }

      }
      return index;
    }
    public static Vector abs(Vector v)
    {
      Vector r = new Vector(v.Length);
      for (int i = 0; i < r.Length; i++)
      {
        r[i] = Math.Abs(v[i]);
      }
      return r;
    }
    public static Vector abs(ComplexVector v)
    {
      Vector r = new Vector(v.Length);
      for (int i = 0; i < r.Length; i++)
      {
        r[i] = v[i].Modulus;
      }
      return r;
    }
    public static double sum(Vector v)
    {
      double s = 0;
      for (int i = 0; i < v.Length; ++i)
      {
        s += v[i];
      }
      return s;
    }

    public static Vector sin(Vector v)
    {
      Vector r = new Vector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = Math.Sin(v[i]);
      }
      return r;
    }
    public static Vector cos(Vector v)
    {
      Vector r = new Vector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = Math.Cos(v[i]);
      }
      return r;
    }
    public static Vector atan2(Vector Y, Vector X)
    {
      Debug.Assert(Y.Length == X.Length);
      Vector r = new Vector(Y.Length);
      for (int i = 0; i < Y.Length; i++)
      {
        r[i] = Math.Atan2(Y[i], X[i]);
      }
      return r;
    }
    /*
    %FILTER One-dimensional digital filter.
    %   Y = FILTER(B,A,X) filters the data in vector X with the
    %   filter described by vectors A and B to create the filtered
    %   data Y.  The filter is a "Direct Form II Transposed"
    %   implementation of the standard difference equation:
    %
    %   a(1)*y(n) = b(1)*x(n) + b(2)*x(n-1) + ... + b(nb+1)*x(n-nb)
    %                         - a(2)*y(n-1) - ... - a(na+1)*y(n-na)
    %
    %   If a(1) is not equal to 1, FILTER normalizes the filter
    %   coefficients by a(1). 
    %
    %   FILTER always operates along the first non-singleton dimension,
    %   namely dimension 1 for column vectors and non-trivial matrices,
    %   and dimension 2 for row vectors.
    %
    %   [Y,Zf] = FILTER(B,A,X,Zi) gives access to initial and final
    %   conditions, Zi and Zf, of the delays.  Zi is a vector of length
    %   MAX(LENGTH(A),LENGTH(B))-1, or an array with the leading dimension 
    %   of size MAX(LENGTH(A),LENGTH(B))-1 and with remaining dimensions 
    %   matching those of X.
    %
    %   FILTER(B,A,X,[],DIM) or FILTER(B,A,X,Zi,DIM) operates along the
    %   dimension DIM.
    %
    %   See also FILTER2 and, in the Signal Processing Toolbox, FILTFILT.

    %   Copyright 1984-2005 The MathWorks, Inc.
    %   $Revision: 5.18.4.4 $  $Date: 2005/06/21 19:23:57 $

    %   Built-in function.
    */
    public static Vector filter(Vector b, Vector a, Vector X)
    {
      Vector x1 = new Vector(b.Length + X.Length);
      Vector Y = new Vector(a.Length - 1 + X.Length);
      x1[slice.init(0, b.Length, 1)] = new Vector(b.Length);
      x1[slice.init(b.Length, X.Length, 1)] = X;
      //Vectorn(b.Length);
      for (int i = 0; i < X.Length; ++i)
      {
        //FIR
        double sum = 0;
        for (int j = 0; j < b.Length; ++j)
          sum += x1[i + b.Length - j] * b[j];
        Y[i + a.Length - 1] = sum;
        //		Vectorn(x[slice(i+b.Length,b.Length,-1)]);
        //		n*=b;
        //		Y[i+a.Length-1] = n.sum();
      }
      if (a.Length - 1 > 0)
      {
        //IIR		
        for (int i = 1; i < X.Length; ++i)
        {
          double sum = 0;
          for (int j = 0; j < a.Length - 1; ++j)
            sum += Y[i + a.Length - 2 - j] * a[j + 1];
          Y[i + a.Length - 1] -= sum;
        }

        //      VectorA(a.shift(1)); 
        //		for(i=1;i<X.Length;++i){
        //			Vectorn(Y[slice(i+a.Length-2,a.Length,-1)]);
        //			n*=A;
        //			Y[i+a.Length-1] -= n.sum();
        //		}
      }
      return Y[slice.init(a.Length - 1, X.Length, 1)];
    }
    public static Vector filter(Vector b, double A, Vector X)
    {
      Vector x1 = new Vector(b.Length + X.Length);
      Vector Y = new Vector(X.Length);

      Debug.Assert(b.Length < int.MaxValue);
      x1[slice.init(0, b.Length, 1)] = new Vector(b.Length);
      x1[slice.init(b.Length, X.Length, 1)] = X;
      //Vectorn(b.Length);
      for (int i = 0; i < X.Length; ++i)
      {
        //FIR
        double sum = 0;
        for (int j = 0; j < b.Length; ++j)
          sum += x1[i + b.Length - j] * b[j];
        Y[i] = sum;
        //		Vectorn(x[slice(i+b.Length,b.Length,-1)]);
        //		n*=b;
        //		Y[i+a.Length-1] = n.sum();
      }
      return Y;
    }

    //double = norm(vector)
    public static double norm(Vector _X)
    {

      double _Ans = 0;
      for (int VALARRAY_IDX = 0; VALARRAY_IDX < _X.Length; ++VALARRAY_IDX)
        _Ans += _X[VALARRAY_IDX] * _X[VALARRAY_IDX];
      return Math.Sqrt(_Ans);
    }

    public static Vector log10(Vector v)
    {
      Debug.Assert(!any(v < 0));  //This routine is not prepared for negative numbers.
      Vector r = new Vector(v.Length);
      for (int i = 0; i < r.Length; i++)
      {
        r[i] = Math.Log10(v[i]);
      }
      return r;
    }
    public static ComplexVector exp(ComplexVector v)
    {
      ComplexVector r = new ComplexVector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        r[i] = v[i].Exponential();
      }
      return r;
    }
    public static ComplexMatrix exp(ComplexMatrix param1)
    {
      Complex[][] newData = new Complex[param1.RowCount][];
      for (int i = 0; i < param1.RowCount; ++i)
      {
        Complex[] newRow = new Complex[param1.ColumnCount];
        for (int j = 0; j < param1.ColumnCount; ++j)
        {
          newRow[j] = param1[i, j].Exponential();
        }
        newData[i] = newRow;
      }
      return new ComplexMatrix(newData);
    }

    public static Vector sqrt(Vector v)
    {
      Vector r = new Vector(v.Length);
      for (int i = 0; i < v.Length; i++)
      {
        if (v[i] < 0)
        {
          throw new ArgumentException("The number must not be negative in the sqrt function!");
        }
        r[i] = Math.Sqrt(v[i]);
      }
      return r;
    }

    public static Vector conv(Vector a, Vector b)
    {
      int na = a.Length;
      int nb = b.Length;

      //% Convolution, polynomial multiplication, and FIR digital
      //% filtering are all the same operations.  Since FILTER
      //% is a fast built-in primitive, we'll use it for CONV.

      //% CONV(A,B) is the same as CONV(B,A), but we can make it go
      //% substantially faster if we swap arguments to make the first
      //% argument to filter the shorter of the two.
      Vector c;
      if (na > nb)
      {
        Vector a1 = null;
        if (nb > 1)
        {
          a1 = new Vector(na + nb - 1);
          a1[slice.init(0, a.Length, 1)] = a;
        }
        else
        {
          a1 = a;
        }
        c = filter(b, 1, a1);
      }
      else
      {
        Vector b1 = null;
        if (na > 1)
        {
          b1 = new Vector(na + nb - 1);
          b1[slice.init(0, b.Length, 1)] = b;
        }
        else
        {
          b1 = b;
        }
        c = filter(a, 1, b1);
      }
      return c;
    }

    public static ComplexVector freqz(Vector b, double A, int N)
    {
      return freqz(b, new Vector(1, A), N);
    }

    public static ComplexVector freqz(Vector b, Vector a, int N)
    {

      /*   % freqvector not specified, use nfft and RANGE in calculation
      */
      Debug.Assert(a.Length < 2 * N);
      Debug.Assert(b.Length < 2 * N);
      a = valcat(a, Vector.Zeros(2 * N - a.Length));
      b = valcat(b, Vector.Zeros(2 * N - b.Length));



      /*
         % dividenowarn temporarily shuts off warnings to avoid "Divide by zero"
         h = dividenowarn(fft(b,s.*nfft),fft(a,s.*nfft)).';
         % When RANGE = 'half', we computed a 2*nfft point FFT, now we take half the result
         h = h(1:nfft);
         h = h(:); % Make it a column only when nfft is given (backwards comp.)
         w = freqz_freqvec(nfft, Fs, s);
         w = w(:); % Make it a column only when nfft is given (backwards comp.)
      */


      //PutVaraiabelToMat("tah.mat","b1",&b);
      RealFourierTransformation rts = new RealFourierTransformation();
      rts.Convention = TransformationConvention.Matlab;
      double[] evenReal, evenImag, oddReal, oddImag;
      rts.TransformForward(b, a, out evenReal, out  evenImag, out oddReal, out oddImag);
      ComplexVector h1 = ComplexVector.Create(evenReal, evenImag);
      ComplexVector h2 = ComplexVector.Create(oddReal, oddImag);
      ComplexVector h = h1 / h2;

      return h[slice.init(0, N, 1)];
    }

    public static ComplexVector freqz(Vector b, double A, Vector N)
    {
      b /= A;
      int n = b.Length;
      ComplexVector digw = ComplexVector.Create(new double[N.Length], N);
      ComplexVector s = exp(digw);
      ComplexVector h1 = polyval(b, s);
      ComplexVector h2 = exp(digw * (n - 1));
      return h1 / h2;
    }

    public static ComplexVector freqz(Vector b, Vector a, Vector N)
    {
      /* %   Frequency vector specified.  Use Horner's method of polynomial
         %   evaluation at the frequency points and divide the numerator
         %   by the denominator.
         %
         %   Note: we use positive i here because of the relationship
         %            polyval(a,exp(i*w)) = fft(a).*exp(i*w*(length(a)-1))
         %               ( assuming w = 2*pi*(0:length(a)-1)/length(a) )
         %        
      */
      int nb = b.Length;
      int na = a.Length;
      int m = Math.Max(nb, na);
      Vector c = null;
      if (na < m)
      {
        c = new Vector(m);
        for (int i = 0; i < a.Length; ++i)
        {
          c[i] = a[i];
        }
      }
      if (nb < m)
      {
        c = new Vector(m);
        for (int i = 0; i < b.Length; ++i)
        {
          c[i] = b[i];
        }
      }





      /*
         if ~isempty(Fs), % Fs was specified, freq. vector is in Hz
            digw = 2.*pi.*w./Fs; % Convert from Hz to rad/sample for computational purposes
         else
            digw = w;
         end
       
         s = exp(i*digw); % Digital frequency must be used for this calculation
         h = polyval(b,s) ./ polyval(a,s);   
      */

      ComplexVector digw = ComplexVector.Create(new double[N.Length], N);
      ComplexVector s = exp(digw);

      ComplexVector h1 = (nb < m) ? polyval(c, s) : polyval(b, s);
      ComplexVector h2 = (na < m) ? polyval(c, s) : polyval(a, s);
      return h1 / h2;
    }
    /*
%POLYVAL Evaluate polynomial.
%   Y = POLYVAL(P,X) returns the value of a polynomial P evaluated at X. P
%   is a vector of length N+1 whose elements are the coefficients of the
%   polynomial in descending powers.
%
%       Y = P(1)*X^N + P(2)*X^(N-1) + ... + P(N)*X + P(N+1)
%
%   If X is a matrix or vector, the polynomial is evaluated at all
%   points in X.  See also POLYVALM for evaluation in a matrix sense.
%
%   [Y,DELTA] = POLYVAL(P,X,S) uses the optional output structure S created
%   by POLYFIT to generate prediction error estimates DELTA.  DELTA is an
%   estimate of the standard deviation of the error in predicting a future
%   observation at X by P(X).
%
%   If the coefficients in P are least squares estimates computed by
%   POLYFIT, and the errors in the data input to POLYFIT are independent,
%   normal, with constant variance, then Y +/- DELTA will contain at least
%   50% of future observations at X.
%
%   Y = POLYVAL(P,X,[],MU) or [Y,DELTA] = POLYVAL(P,X,S,MU) uses XHAT =
%   (X-MU(1))/MU(2) in place of X. The centering and scaling parameters MU
%   are optional output computed by POLYFIT.
%
%   Class support for inputs P,X,S,MU:
%      float: double, single
%
%   See also POLYFIT, POLYVALM.

%   Copyright 1984-2004 The MathWorks, Inc.
%   $Revision: 5.16.4.4 $  $Date: 2004/07/05 17:01:38 $

%   DELTA can be used to compute a 100(1-alpha)% prediction interval
%   for future observations at X, as Y +/- DELTA*t(alpha/2,df), where
%   t(alpha/2,df) is the upper (alpha/2) quantile of the Student's t
%   distribution with df degrees of freedom.  Since t(.25,df) < 1 for any
%   degrees of freedom, Y +/- DELTA is at least a 50% prediction interval
%   in all cases.  For large degrees of freedom, the confidence level
%   approaches approximately 68%.
*/
    public static ComplexVector polyval(Vector p, ComplexVector x)
    {
      int nc = p.Length;
      int siz_x = x.Length;
      /*
        % Use Horner's method for general case where X is an array.
        y = zeros(siz_x, superiorfloat(x,p));
        if nc>0, y(:) = p(1); end
        for i=2:nc
          y = x .* y + p(i);
        end
      */
      ComplexVector y = new ComplexVector(siz_x);
      if (nc > 0)
      {
        y = y + p[0];
      }
      for (int i = 1; i < nc; ++i)
      {
        y = (x * y) + p[i];
      }
      return y;
    }

    public static Vector interp1(Vector x, Vector Y, Vector xi)
    {
      return interp1(x, Y, xi, Interp1Type.Linear);
    }

    public static Vector interp1(Vector x, Vector Y, Vector xi, Interp1Type intertp1Type)
    {
      Vector r = new Vector(xi.Length);
      IInterpolationMethod method = null;
      switch (intertp1Type)
      {
        case Interp1Type.Linear:
          method = Interpolation.Interpolation.CreateLinearSpline(x, Y);
          break;
        case Interp1Type.Cubic:
          method = Interpolation.Interpolation.CreateCubicSpline(x, Y, SplineBoundaryCondition.SecondDerivative, 0, SplineBoundaryCondition.SecondDerivative, 0);
          break;
        case Interp1Type.Hermite:
          method = Interpolation.Interpolation.CreateHermiteSpline(x, Y);
          break;
        case Interp1Type.AkimaCubic:
          method = Interpolation.Interpolation.CreateAkimaCubicSpline(x, Y);
          break;
      }
      for (int i = 0; i < r.Length; i++)
      {
        r[i] = method.Interpolate(xi[i]);
      }
      return r;
    }
    
    //vector = find(vector)
    public static int[] find(Vector _X)
    {
      int _C = 0;
      for (int i = 0; i < _X.Length; ++i)
        if (_X[i] != 0) ++_C;
      int[] _Ans = new int[_C];
      _C = 0;
      for (int i = 0; i < _X.Length; ++i)
        if (_X[i] != 0) _Ans[_C++] = i;
      return (_Ans);
    }
    public static int[] find(BoolVector _X)
    {
      int _C = 0;
      for (int i = 0; i < _X.Length; ++i)
        if (_X[i] != false) ++_C;
      int[] _Ans = new int[_C];
      _C = 0;
      for (int i = 0; i < _X.Length; ++i)
        if (_X[i] != false) _Ans[_C++] = i;
      return (_Ans);
    }

    public static ComplexVector eig(Matrix A)
    {

      //double[] a1 = A.GetComponenets();      
      //double[] b = new double[A.RowCount * A.RowCount];
      //double[] c = new double[A.RowCount];
      //double[] d = new double[A.RowCount];
      //int num2;
      //Kernel.Lapack.Dgeev('N', 'V', A.RowCount, a1, 0, A.RowCount, c, d, b, A.RowCount, b, A.RowCount, out  num2);
      //return ComplexVector.Create(c,d);

      EigenvalueDecomposition e = A.EigenvalueDecomposition;
      return e.EigenValues;
    }
    public static Matrix diag(Vector v, int k)
    {
      Matrix Ans = new Matrix(v.Length + Math.Abs(k), v.Length + Math.Abs(k));
      if (k >= 0)
        for (int i = 0; i < v.Length; ++i)
          Ans[i, k + i] = v[i];
      else
        for (int i = 0; i < v.Length; ++i)
          Ans[i - k, i] = v[i];
      return Ans;

    }
    public static Vector diag(Matrix _X)
    {
      if (_X.RowCount != _X.ColumnCount)
        throw new ArgumentException("I must be a squared matrix");
      Vector _Ans = new Vector(_X.ColumnCount);
      for (int _I = 0; _I < _Ans.Length; ++_I)
        _Ans[_I] = _X[_I, _I];
      return _Ans;

    }

    public static ComplexVector roots(Vector V)
    {
      int n = V.Length;
      //v = reshape (v, 1, n);

      //## If v = [ 0 ... 0 v(k+1) ... v(k+l) 0 ... 0 ], we can remove the
      //## leading k zeros and n - k - l roots of the polynomial are zero.

      int[] f = find(V);
      int m = f.Length;
      ComplexVector r = ComplexVector.Zeros(n - f[m - 1] - 1);
      if (m > 0 && n > 1)
      {
        Vector v = new Vector(V[slice.init(f[0], f[m - 1] - f[0] + 1, 1)]);
        int l = v.Length;
        if (l > 1)
        {
          Vector ones = Vector.Ones(l - 2);
          Matrix A = diag(ones, -1);
          Vector tmp = new Vector(v[slice.init(1, l - 1, 1)]); tmp /= -v[0];
          for (int i = 0; i < tmp.Length; ++i)
            A[0, i] = tmp[i];
          r = valcat(r, eig(A));
        }
        else
        {
          r = new ComplexVector(n - f[m - 1]);
        }
      }
      return r;
    }

    public static Vector real(ComplexVector v)
    {
      Vector rv = new Vector(v.Length);
      for (int i = 0; i < rv.Length; ++i)
      {
        rv[i] = v[i].Real;
      }
      return rv;
    }


    public static Vector imag(ComplexVector v)
    {
      Vector iv = new Vector(v.Length);
      for (int i = 0; i < iv.Length; ++i)
      {
        iv[i] = v[i].Imag;
      }
      return iv;
    }

    /// <summary>
    ///%INVFREQZ  Discrete filter least squares fit to frequency response data.
    ///%
    ///%	[B,A] = INVFREQZ(H,W,NB,NA) gives real numerator and denominator 
    ///%	coefficients B and A of orders NB and NA respectively, where
    ///%	H is the desired complex frequency response of the system at frequency
    ///%	points W, and W contains the frequency values in radians/s.
    ///%
    ///%	[B,A]=INVFREQZ(H,W,NB,NA,Wt) allows the fit-errors to the weighted
    ///%	versus frequency.  LENGTH(Wt)=LENGTH(W)=LENGTH(H).
    ///%	Determined by minimization of sum |B-H*A|^2*Wt over the freqs in W.
    ///%
    ///%	[B,A] = INVFREQZ(H,W,NB,NA,Wt,ITER) does another type of fit:
    ///%	Sum |B/A-H|^2*Wt is minimized with respect to the coefficients in B and
    ///%	A by numerical search in at most ITER iterations.  The A-polynomial is 
    ///%	then constrained to be stable.  [B,A]=INVFREQZ(H,W,NB,NA,Wt,ITER,TOL)
    ///%	stops the iterations when the norm of the gradient is less than TOL.
    ///%	The default value of TOL is 0.01.  The default value of Wt is all ones.
    ///%	This default value is also obtained by Wt=[].
    ///%
    ///%	[B,A]=INVFREQZ(H,W,NB,NA,Wt,ITER,TOL,'trace') will provide a textual
    ///%	progress report of the iteration.
    ///%
    ///%	See also FREQZ, FREQS, and INVFREQS.
    ///
    ///%	Author(s): J.O. Smith and J.N. Little, 4-23-86
    ///%		   J.N. Little, 4-27-88, revised 
    ///%		   Lennart Ljung, 9-21-92, rewritten
    ///%		   T. Krauss, 10-19-92, trace mode made optional
    ///%	Copyright (c) 1984-94 by The MathWorks, Inc.
    ///%	$Revision: 1.11 $  $Date: 1994/01/25 17:59:21 $    /// 
    /// </summary>
    /// <param name="g"></param>
    /// <param name="w"></param>
    /// <param name="nb"></param>
    /// <param name="na"></param>
    /// <returns></returns>
    public static Vector invfreqz(ComplexVector g, Vector w, int nb, int na)
    {
      nb = nb + 1;


      //if length(g)~=length(w),error('The lengths of H and W must coincide'),end
      if (g.Length != w.Length)
        throw new ArgumentException("Input vectors do not have the same size");



      //nm=max(na,nb+nk-1); 
      //OM=exp(-i*(0:nm)'*w*T);
      int nm = Math.Max(na, nb);
      ComplexMatrix OM = exp(transpose(real2imag(linspace(0, nm, nm + 1)), true) * reshape(w, 1, w.Length));


      //%
      //% Estimation in the least squares case:
      //%
      //Dva=(OM(2:na+1,:).').*(g*ones(1,na));
      //Dvb=-(OM(nk+1:nk+nb,:).');
      //D=[Dva Dvb].*(wf*ones(1,na+nb));
      //if realFlag
      //    R=real(D'*D);
      //    Vd=real(D'*(-g.*wf));
      //else
      //    R=D'*D;
      //    Vd=D'*(-g.*wf);
      //end
      //th=R\Vd;
      //a=[1 th(1:na).'];b=[zeros(1,nk) th(na+1:na+nb).'];
      ComplexMatrix Dva = null;
      if (na > 0)
      {
        Dva = new ComplexMatrix(OM.ColumnCount, na);
        for (int i = 0; i < na; ++i)
          Dva.SetColumnVector(OM.GetRowVector(1 + i), i);
        Dva.MultiplyInplace(g);
      }

      if (nb != nm)
      {
        throw new ArgumentException("nb is too small");
      }

      ComplexMatrix Dvb = new ComplexMatrix(OM.ColumnCount, nb);
      for (int i = 0; i < nb; ++i)
        Dvb.SetColumnVector(OM.GetRowVector(i), i);
      Dvb *= -1;


      ComplexMatrix D = horzcat(Dva, Dvb);


      Matrix R = D.realATxA();
      Matrix Vd = D.realAconjxBdT(reshape(g * new Complex(-1, 0), 1, g.Length));
      Vector th = R.CholeskyDecomposition.Solve(Vd).GetColumnVector(0);
      return th[slice.init(na, nb, 1)];
    }



    [Obsolete("This function is too slow")]
    public static Matrix realmultiply(TransposeComplexMatrix x, ComplexMatrix y)
    {
      if (y.RowCount != x.ColumnCount)
      {
        throw new ArgumentException("Same size");
      }

      double[][] newData = new double[x.RowCount][];
      for (int i = 0; i < newData.Length; i++)
      {
        double[] newRow = new double[y.ColumnCount];
        for (int j = 0; j < newRow.Length; j++)
        {
          double s = 0;
          for (int k = 0; k < x.ColumnCount; k++)
          {
            //(x + yi)(u + vi) = (xu – yv) + (xv + yu)i. 
            s += x[i, k].Real * y[k, j].Real - x[i, k].Imag * y[k, j].Imag;
          }

          newRow[j] = s;
        }

        newData[i] = newRow;
      }

      return new Matrix(newData);

    }

    public static ComplexMatrix horzcat(ComplexMatrix cm1, ComplexMatrix cm2)
    {
      if (Object.Equals(cm1, null))
      {
        return cm2;
      }
      if (Object.Equals(cm2, null))
      {
        return cm1;
      }

      if (cm1.RowCount != cm2.RowCount)
      {
        throw new ArgumentException("The matrix must have the same numbers of rows");
      }

      ComplexMatrix cm = new ComplexMatrix(cm1.RowCount, cm1.ColumnCount + cm2.ColumnCount);
      for (int i = 0; i < cm.RowCount; ++i)
      {
        int p = 0;
        for (int j = 0; j < cm1.ColumnCount; ++j)
        {
          cm[i, p++] = cm1[i, j];
        }
        for (int j = 0; j < cm2.ColumnCount; ++j)
        {
          cm[i, p++] = cm2[i, j];
        }
      }
      return cm;



    }



    //public static Matrix chols(Matrix A, Matrix C,out TimeSpan tp)
    //{

    //  GeneralMatrix a = GeneralMatrix.Create(A.CopyToArray());
    //  SymmetricMatrix s = SymmetricMatrix.CreateSymmetric(A.RowCount,a.GetComponents(),MatrixTriangleMode.Upper);
    //  DateTime start = DateTime.Now;
    //  GeneralMatrix R = s.Solve(GeneralMatrix.Create(C.CopyToArray()));
    //  tp = DateTime.Now.Subtract(start);
    //  Matrix Re = new Matrix(R.RowCount,R.ColumnCount);
    //  for(int r=0;r<R.RowCount;++r)
    //  {
    //    for (int c=0;c<R.ColumnCount;++c)
    //    {
    //      Re[r,c] = R[r,c];
    //    }
    //  }
    //  return Re;
    //}

    public static ComplexVector real2imag(Vector v)
    {
      return ComplexVector.Create(Vector.Zeros(v.Length), v);
    }

    public static TransposeComplexMatrix transpose(ComplexMatrix _X)
    {
      return new TransposeComplexMatrix(_X);
    }

    public static TransposeComplexMatrix transpose(ComplexMatrix _X, bool conj)
    {
      return new TransposeComplexMatrix(_X, conj);
    }


    public static ComplexMatrix transpose(ComplexVector v, bool conj)
    {
      ComplexMatrix cm = new ComplexMatrix(v, 1);
      return conj ? cm.HermitianTranspose() : cm.Transpose();
    }

    public static Matrix reshape(Vector v, int row, int col)
    {
      if (object.Equals(null, v)) return null;
      Matrix m = new Matrix(row, col);
      int k = 0;
      for (int i = 0; i < row; ++i)
      {
        for (int j = 0; j < col; ++j)
        {
          m[i, j] = v[k++];
        }
      }
      return m;
    }
    public static ComplexMatrix reshape(ComplexVector v, int row, int col)
    {
      if (object.Equals(null, v)) return null;
      if (v.Length != row * col)
      {
        throw new ArgumentException("Wrong size of array");
      }
      ComplexMatrix m = new ComplexMatrix(row, col);
      int k = 0;
      for (int i = 0; i < row; ++i)
      {
        for (int j = 0; j < col; ++j)
        {
          m[i, j] = v[k++];
        }
      }
      return m;
    }

    public static Vector pow(Vector b, int p)
    {
      double[] newData = new double[b.Length];
      for (int i = 0; i < b.Length; ++i)
      {
        newData[i] = Math.Pow(b[i], p);
      }
      return new Vector(newData);
    }
    public static Vector pow(double b, Vector p)
    {
      double[] newData = new double[p.Length];
      for (int i = 0; i < p.Length; ++i)
      {
        newData[i] = Math.Pow(b,p[i]);
      }
      return new Vector(newData);
    }

    public static double mean(Vector v)
    {
      double newData = 0;
      for (int i = 0; i < v.Length; ++i)
      {
        newData += v[i];
      }
      return newData / v.Length;
    }
    //(diag(X)) is a diagonal matrix.

    public static Matrix eye(int p)
    {
      double[][] newData = new double[p][];
      for (int i = 0; i < newData.Length; ++i)
      {
        double[] rowData = new double[p];
        rowData[i] = 1;
        newData[i] = rowData;
      }
      return new Matrix(newData);
    }


    public static ComplexMatrix transpose(ComplexVector complexVector)
    {
      Complex[][] newData = new Complex[complexVector.Length][];
      for (int i = 0; i < newData.Length; ++i)
      {
        Complex[] newRow = new Complex[1];
        newRow[0] = complexVector[i].Conjugate;
        newData[i] = newRow;
      }
      return new ComplexMatrix(newData);
    }

    public static Matrix transpose(Vector vector)
    {
      double[][] newData = new double[vector.Length][];
      for (int i = 0; i < newData.Length; ++i)
      {
        double[] newRow = new double[1];
        newRow[0] = vector[i];
        newData[i] = newRow;
      }
      return new Matrix(newData);
    }


    public static ComplexVector poly(ComplexVector x)
    {
      Complex[] newData = new Complex[x.Length + 1];
      newData[0] = 1;
      for (int j = 0; j < x.Length; ++j)
      {
        for (int i = (int)j; i >= 0; --i)
          newData[i + 1] -= x[j] * newData[i];
      }
      return new ComplexVector(newData);
    }

    public static Vector sign(Vector vector)
    {
      double[] newData = new double[vector.Length];
      for (int i = 0; i < newData.Length; ++i)
      {
        newData[i] = vector[i] < 0 ? -1 : 1;
      }
      return new Vector(newData);
    }

    public static int[] findpeaks(Vector x, FindPeaks.FindPeakType peakType, int mpd)
    {
      FindPeaks fp = new FindPeaks(x, peakType, mpd);
      return fp.locs;
    }

    public static Vector diff(IList<double> x)
    {
      double[] res = new double[x.Count-1];
      for (int i = 0; i < res.Length; i++)
      {
        res[i] = x[i+1] - x[i]; 
      }
      return new Vector(res);
    }
  }
  public enum Interp1Type
  {
    Linear,
    Cubic,
    Hermite,
    AkimaCubic
  }

}
