﻿// Added functionality for testing function added by GN Resound

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using MbUnit.Framework;
using MathNet.Numerics.Distributions;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics;
using System.Globalization;

namespace Iridium.Test
{
  [TestFixture]
  public class AddedFunctionality
  {
    Complex j = Complex.I;

    [Test]
    public void TestLength()
    {
      Assert.AreEqual(5, Matlab.length(new Vector(5)));
      Vector newVariable = null;
      Assert.AreEqual(0, Matlab.length(newVariable));
      Assert.AreEqual(5, Matlab.length(new ComplexVector(5)));
      ComplexVector newVariable1 = null;
      Assert.AreEqual(0, Matlab.length(newVariable1));
      Assert.AreEqual(6, Matlab.length(new Matrix(5, 6)));
      Matrix newVariable2 = null;
      Assert.AreEqual(0, Matlab.length(newVariable2));
    }

    /// <summary>
    /// Test of BoolVector
    /// <list type="bullet">
    /// <item>Operator overload Vector > double</item>
    /// <item>Operator overload Vector < double</item>
    /// </list>
    /// </summary>
    [Row("[4 6 -7 5.51]", 5.5, new bool[] { false, true, false, true })]
    [Row("[4]", 5.5, new bool[] { false })]
    [Row("[6]", 5.5, new bool[] { true })]
    [Row("[-4]", -5.5, new bool[] { true })]
    [Row("[-6]", -5.5, new bool[] { false })]
    [RowTest]
    public void TestsGreaterThan(string input, double greater, bool[] expected)
    {
      BoolVector r = Vector.ParseMatlabString(input) > greater;
      Check.Array(new BoolVector(expected), r, "#A01");
    }

    [Row("[4 6 -7 5.5]", 5.5, new bool[] { true, false, true, false })]
    [Row("[4]", 5.5, new bool[] { true })]
    [Row("[6]", 5.5, new bool[] { false })]
    [Row("[-6]", -5.5, new bool[] { true })]
    [Row("[-4]", -5.5, new bool[] { false })]
    [RowTest]
    public void TestsLessThan(string input, double greater, bool[] expected)
    {

      BoolVector r = Vector.ParseMatlabString(input) < greater;
      Check.Array(new BoolVector(expected), r, "#A01");
    }

    /// <summary>
    /// Test of BoolVector
    /// <list type="bullet">
    /// <item>Operator overload Vector > double</item>
    /// <item>Operator overload Vector < double</item>
    /// </list>
    /// </summary>
    [Row(5.5, "[4 6 -7 5.5]", new bool[] { true, false, true, false })]
    [Row(5.5, "[4]", new bool[] { true })]
    [Row(5.5, "[6]", new bool[] { false })]
    [Row(-5.5, "[-6]", new bool[] { true })]
    [Row(-5.5, "[-4]", new bool[] { false })]
    [RowTest]
    public void TestsGreaterThan(double greater, string input, bool[] expected)
    {
      BoolVector r = greater > Vector.ParseMatlabString(input);
      Check.Array(new BoolVector(expected), r, "#A01");
    }

    [Row(5.5, "[4 6 -7 5.51]", new bool[] { false, true, false, true })]
    [Row(5.5, "[4]", new bool[] { false })]
    [Row(5.5, "[6]", new bool[] { true })]
    [Row(-5.5, "[-4]", new bool[] { true })]
    [Row(-5.5, "[-6]", new bool[] { false })]
    [RowTest]
    public void TestsLessThan(double greater, string input, bool[] expected)
    {

      BoolVector r = greater < Vector.ParseMatlabString(input);
      Check.Array(new BoolVector(expected), r, "#A01");
    }

    /// <summary>
    /// Test C# implementation af matlab function.
    /// 
    /// Following tets are performed
    /// <list type="bullet">
    /// <item>Normalize</item>
    /// <item>any</item>
    /// <item>isempty</item>
    /// <item>valcat  Matlab function cat(2,a,b)</item>
    /// <item>slice of vector</item>
    /// <item>linspace</item>
    /// <item>circshift</item>
    /// </list>
    /// </summary>
    [Row("[-0.4 0.8 0.01]", 0.894483090952535)]
    [Row("[-0.5]", 0.5)]
    [RowTest]
    public void TestNorm(string input, double expected)
    {
      Assert.AreEqual(expected, Matlab.norm(Vector.ParseMatlabString(input)), 1e-12, "#B00 Unexpected result");
    }


    [Row(new bool[] { false, false, false, true }, true)]
    [Row(new bool[] { true, false, false, false }, true)]
    [Row(new bool[] { false, true, false, true, false, false }, true)]
    [Row(new bool[] { false, false, false }, false)]
    [Row(new bool[] { false }, false)]
    [Row(new bool[] { true }, true)]
    [RowTest]
    public void TestAny(bool[] input, bool expected)
    {
      Assert.AreEqual(expected, Matlab.any(new BoolVector(input)));
    }

    [Row(new double[] { 1, 2 }, false)]
    [Row(new double[] { }, true)]
    [Row(null, true)]
    [RowTest]
    public void TestIsempty(double[] input, bool expected)
    {
      if (Object.Equals(null, input))
      {
        Assert.AreEqual(expected, Matlab.isempty(null));
      }
      else
      {
        Assert.AreEqual(expected, Matlab.isempty(input));
      }

    }

    [Row("[5 4 3]", "[2 1 0 -1]", "[5 4 3 2 1 0 -1]")]
    [RowTest]
    public void TestValcat(string in1, string in2, string expected)
    {
      Check.Array(Vector.ParseMatlabString(expected), Matlab.valcat(Vector.ParseMatlabString(in1), Vector.ParseMatlabString(in2)), 0, "#B07");
    }
    [Row(4, "[2 1 0 -1]", "[4 2 1 0 -1]")]
    [RowTest]
    public void TestValcat(double in1, string in2, string expected)
    {
      Check.Array(Vector.ParseMatlabString(expected), Matlab.valcat(in1, Vector.ParseMatlabString(in2)), 0, "#B08");
    }

    [Row("[2; 1; 0 ;-1]", "[4; 3; 1 ;-2]", "[2 4;1 3;0 1;-1 -2]")]
    [Row("[2]", "[4]", "[2 4]")]
    [Row("[2; i; 0 ;-i]", "[7+4i; 3; 1 ;-2]", "[2 7+4i;i 3;0 1;-i -2]")]
    [Row(null, "[7+4i; 3; 1 ;-2]", "[7+4i;3;1;-2]")]
    [Row("[2; i; 0 ;-i]", null, "[2;i;0;-i]")]
    [RowTest]
    public void TestHorxcat(string in1, string in2, string expected)
    {
      Check.Array(ComplexMatrix.ParseMatlabString(expected), Matlab.horzcat(ComplexMatrix.ParseMatlabString(in1), ComplexMatrix.ParseMatlabString(in2)), 0);
    }

    [Row(4, 0, 2, 1, "[1 1]", "[1 1 0 0]")]
    [Row(6, 0, 3, 2, "[1 1 1]", "[1 0 1 0 1 0]")]
    [RowTest]
    public void Testslice(int len, int start, int length, int stride, string input, string expected)
    {
      Vector r = new Vector(len);
      r[slice.init(start, length, stride)] = Vector.ParseMatlabString(input);
      Check.Array(Vector.ParseMatlabString(expected), r, 0, "#B09");
    }

    [Row(1, 2, 1, "[1 2 3 4 5 6]", "[2 3]")]
    [Row(0, 3, 2, "[1 2 3 4 5 6]", "[1 3 5]")]
    [Row(3, 0, 1, "[1 2 3 4 5 6]", "[]")]
    [RowTest]
    public void Testslice(int start, int length, int stride, string input, string expected)
    {
      Vector v = Vector.ParseMatlabString(input);
      Vector r = v[slice.init(start, length, stride)];
      Check.Array(Vector.ParseMatlabString(expected), r, 0, "#B11");
    }

    [Row(1, 2, 1, "[1 2 3 4 5 6]", "[0 2 3]")]
    [Row(2, 2, 2, "[1 2 3 4 5 6]", "[0 3 5]")]
    [RowTest]
    public void Testslice2(int start, int length, int stride, string input, string expected)
    {
      Vector v = Vector.ParseMatlabString(input);
      Vector r = new Vector(length + 1);
      r[slice.init(1, length, 1)] = v[slice.init(start, length, stride)];
      Check.Array(Vector.ParseMatlabString(expected), r, 0, "#B11");
    }

    [Row(1, 4, 3, "[1 2.5 4]")]
    [Row(1, 4, 1, "[1]")]
    [RowTest]
    public void TestLinspace(int start, int end, int len, string expected)
    {
      Vector r = Matlab.linspace(start, end, len);
      Vector e = Vector.ParseMatlabString(expected);
      Check.Array(e, r, 0, "#B13");
    }

    [Row("[1 2 3 4 5 6]", 1, "[6 1 2 3 4 5]")]
    [Row("[1 2 3 4 5 6]", -1, "[2 3 4 5 6 1]")]
    [Row("[1 2 3 4 5 6]", 0, "[1 2 3 4 5 6]")]
    [Row("[1 2 3 4 5 6]", -5, "[6 1 2 3 4 5]")]
    [Row("[1 2 3 4 5 6]", 7, "[6 1 2 3 4 5]")]
    [Row("[1 2 3 4 5 6]", 6, "[1 2 3 4 5 6]")]
    [Row("[1 2 3 4 5 6]", 12, "[1 2 3 4 5 6]")]
    [Row("[1 2 3 4 5 6]", -15, "[4 5 6 1 2 3]")]
    [RowTest]
    public void TestCircshift(string input, int shift, string expected)
    {
      Vector v = Vector.ParseMatlabString(input);
      Vector r = Matlab.circshift(v, shift);
      Vector e = Vector.ParseMatlabString(expected);
      Check.Array(e, r, 0, "#B14");
    }

    [Row(new bool[] { true, false, true }, new int[] { 0, 2 })]
    [Row(new bool[] { true, false }, new int[] { 0 })]
    [Row(new bool[] { true }, new int[] { 0 })]
    [Row(new bool[] { false }, new int[] { })]
    [RowTest]
    public void TestFind(bool[] v, int[] expected)
    {
      Check.Array(expected, Matlab.find(new BoolVector(v)), "");
    }

    [Row(new double[] { 0, -2.3, 3 }, new int[] { 1, 2 })]
    [Row(new double[] { 0, 0.03 }, new int[] { 1 })]
    [Row(new double[] { 0 }, new int[] { })]
    [Row(new double[] { -1 }, new int[] { 0 })]
    [RowTest]
    public void TestFind(double[] v, int[] expected)
    {
      Check.Array(expected, Matlab.find(new Vector(v)), "");
    }

    [Row(new bool[] { true }, true)]
    [Row(new bool[] { false }, false)]
    [Row(new bool[] { false, true }, false)]
    [Row(new bool[] { true, false }, false)]
    [Row(new bool[] { false, false }, false)]
    [Row(new bool[] { true, true }, true)]
    [RowTest]
    public void TestAll(bool[] v, bool expected)
    {
      Assert.AreEqual(expected, Matlab.all(new BoolVector(v)), "");
    }

    [Row(new double[] { 1, 2, 3, 4, 5, 3, 4 }, 5)]
    [Row(new double[] { 4, 5, 6, 7 }, 7)]
    [Row(new double[] { 9, 5, 6, 7 }, 9)]
    [Row(new double[] { -4, 5, 6, -10 }, 6)]
    [Row(new double[] { -4, -5, -6, -10 }, -4)]
    [RowTest]
    public void TestMax(double[] v, double expected)
    {
      Assert.AreEqual(expected, Matlab.max(v));
    }

    [Row(new double[] { 1, 2, 3, 4 }, 3, new double[] { 3, 3, 3, 4 })]
    [Row(new double[] { 2 }, 1, new double[] { 2 })]
    [Row(new double[] { -5, 1.1 }, -6, new double[] { -5, 1.1 })]
    [RowTest]
    public void TestMax(double[] v, double s, double[] expected)
    {
      Check.Array(expected, Matlab.max(v, s), 0, "");
      Check.Array(expected, Matlab.max(s, v), 0, "");
    }

    [Row(new double[] { 1, 2, 3, 4, 5, 3, 4 }, 4)]
    [Row(new double[] { 4, 5, 6, 7 }, 3)]
    [Row(new double[] { 9, 5, 6, 7 }, 0)]
    [Row(new double[] { 7, 9, 9, 7 }, 1)]
    [Row(new double[] { -7, -9, -1, -7 }, 2)]
    [RowTest]
    public void TestMaxi(double[] v, int expected)
    {
      Assert.AreEqual(expected, Matlab.maxi(v));
    }

    [Row(new double[] { 1, 2, 3, 4, 5, 3, 4 }, 1)]
    [Row(new double[] { 4, 5, 6, 2 }, 2)]
    [Row(new double[] { 9, 5, 6, 7 }, 5)]
    [Row(new double[] { -4, 5, -6, 10 }, -6)]
    [RowTest]
    public void TestMin(double[] v, double expected)
    {
      Assert.AreEqual(expected, Matlab.min(v));
    }


    [Row(new double[] { 4, 5, 6, 2 }, new double[] { 3, 1, 7, 5 }, new double[] { 3, 1, 6, 2 })]
    [Row(new double[] { -4, -5, 6, 2 }, new double[] { -3, -1, -7, -5 }, new double[] { -4, -5, -7, -5 })]
    [RowTest]
    public void TestMin(double[] a, double[] b, double[] expected)
    {
      ArrayAssert.AreEqual(expected, Matlab.min(a, b), 0);
    }

    [Row(new double[] { 1, 2, 3, 4 }, 3, new double[] { 1, 2, 3, 3 })]
    [Row(new double[] { 2 }, 1, new double[] { 1 })]
    [Row(new double[] { -5, -7.2 }, -6, new double[] { -6, -7.2 })]
    [RowTest]
    public void TestMin(double[] v, double s, double[] expected)
    {
      Check.Array(expected, Matlab.min(v, s), 0, "");
      Check.Array(expected, Matlab.min(s, v), 0, "");
    }

    private ComplexVector ComplexCreate(double[] v)
    {
      Assert.AreEqual(0, v.Length % 2);
      ComplexVector r = new ComplexVector(v.Length / 2);
      for (int i = 0, j = 0; i < r.Length; i++, j += 2)
      {
        r[i] = new Complex(v[j], v[j + 1]);
      }
      return r;
    }

    [Row("[3+5i]", "[5.69750729983374-19.2605089252874i]")]
    [Row("[3+5i 3-i;4-4.1i 5-2i]", "[5.697507299833739-19.260508925287420i 10.852261914197959-16.901396535150095i;-31.384324075467510+44.676416478582500i -6.176166666250499e+01-1.349517036790434e+02i]")]
    [RowTest]
    public void Testexp(string input, string expected)
    {

      Check.Array(ComplexMatrix.ParseMatlabString(expected), Matlab.exp(ComplexMatrix.ParseMatlabString(input)), 1e-12);
    }

    [Row("[2]", "[2]")]
    [Row("[2 4;6 -7]", "[2 -7]")]
    [RowTest]
    public void TestDiag(string input, string expected)
    {
      Vector vectorParseMatlabString = Vector.ParseMatlabString(expected);
      Matrix matrixParseMatlabString = Matrix.ParseMatlabString(input);
      Check.Array(vectorParseMatlabString, Matlab.diag(matrixParseMatlabString), 0, "");
    }

    [Row("[-2]", -1, "[0 0;-2 0]")]
    [Row("[3 4]", 1, "[0 3 0;0 0 4;0 0 0]")]
    [Row("[3 4]", -1, "[0 0 0;3 0 0;0 4 0]")]
    [Row("[-2 6]", -4, "[0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;-2 0 0 0 0 0;0 6 0 0 0 0]")]
    [Row("[-1 4]", 4, "[0 0 0 0 -1 0;0 0 0 0 0 4;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0;0 0 0 0 0 0]")]
    [RowTest]
    public void TestDiag(string input, int k, string expected)
    {
      Vector vectorParseMatlabString = Vector.ParseMatlabString(input);
      Check.Array(Matrix.ParseMatlabString(expected), Matlab.diag(vectorParseMatlabString, k), 0);
    }

    [Row(new double[] { 7, 9, 9, 7 }, new double[] { 7, 9, 9, 7 })]
    [Row(new double[] { -2, -3, -4, -5 }, new double[] { 2, 3, 4, 5 })]
    [Row(new double[] { 7, -9, 9, 7 }, new double[] { 7, 9, 9, 7 })]
    [RowTest]
    public void TestAbs(double[] v, double[] e)
    {
      Check.Array(e, Matlab.abs(v), 0, "");
    }


    [Row(new double[] { 4 }, new double[] { 5 }, new double[] { 6.403124237432849 })]
    [Row(new double[] { 4, -3 }, new double[] { 5, -6 }, new double[] { 6.403124237432849, 6.70820393249937 })]
    [RowTest]
    public void TestAbs(double[] real, double[] imag, double[] e)
    {
      ComplexVector vc = ComplexVector.Create(real, imag);
      Check.Array(e, Matlab.abs(vc), 1e-12, "");
    }

    [Row(new double[] { 4, -3 }, 1)]
    [Row(new double[] { 4 }, 4)]
    [Row(new double[] { -3.2 }, -3.2)]
    [RowTest]
    public void TestAbs(double[] real, double e)
    {
      Assert.AreEqual(e, Matlab.sum(real));
    }

    [Row(new double[] { 10 }, new double[] { 1 })]
    [Row(new double[] { 10, 20 }, new double[] { 1, 1.30102999566398 })]
    [RowTest]
    public void Testlog10(double[] v, double[] e)
    {
      Check.Array(e, Matlab.log10(v), Math.Pow(10, -14), "");
    }

    [Row(new double[] { 0.5 }, new double[] { 0.479425538604203 })]
    [Row(new double[] { 0.6, 0.8, -0.7 }, new double[] { 0.564642473395035, 0.717356090899523, -0.644217687237691 })]
    [RowTest]
    public void Testsin(double[] v, double[] e)
    {
      Check.Array(e, Matlab.sin(v), Math.Pow(10, -14), "");
    }

    [Row(new double[] { 0.5 }, new double[] { 0.877582561890373 })]
    [Row(new double[] { 0.6, 0.8, -0.7 }, new double[] { 0.825335614909678, 0.696706709347165, 0.764842187284489 })]
    [RowTest]
    public void Testcos(double[] v, double[] e)
    {
      Check.Array(e, Matlab.cos(v), Math.Pow(10, -14), "");
    }

    [Row(new double[] { 3, 4 }, new double[] { 2, -2 }, new double[] { 0.982793723247329, 2.03444393579570 })]
    [Row(new double[] { 0.7 }, new double[] { 0.3 }, new double[] { 1.16590454050981 })]
    [RowTest]
    public void TestAtan2(double[] Y, double[] X, double[] e)
    {
      Check.Array(e, Matlab.atan2(Y, X), 1e-13, "");
    }

    [Row("[3]", "[1.732050807568877]")]
    [Row("[3 5]", "[1.732050807568877 2.236067977499790]")]
    [Row("[-3]", "[]", ExpectedException = typeof(ArgumentException))]
    [RowTest]
    public void TestSqrt(string input, string expected)
    {
      Check.Array(Vector.ParseMatlabString(expected), Matlab.sqrt(Vector.ParseMatlabString(input)), 1e-12);
    }
    [Row("[0 1 2 3 4 5 6 7 8 9 10]", "[0 0.841470984807897 0.909297426825682 0.141120008059867 -0.756802495307928 -0.958924274663139 -0.279415498198926 0.656986598718789 0.989358246623382 0.412118485241757 -0.544021110889370]",
      "[0 0.250 0.50 0.750 1 1.25 1.50 1.75 2 2.25 2.50 2.75 3 3.25 3.50 3.75 4 4.25 4.50 4.75 5 5.25 5.50 5.75 6 6.25 6.50 6.75 7 7.25 7.50 7.75 8 8.25 8.50 8.75 9 9.25 9.50 9.75 10]",
      "[0 0.210367746201974 0.420735492403948 0.631103238605922 0.841470984807897 0.858427595312343 0.875384205816789 0.892340816321235 0.909297426825682 0.717253072134228 0.525208717442774 0.333164362751321 0.141120008059867 -0.0833606177820817 -0.307841243624031 -0.532321869465979 -0.756802495307928 -0.807332940146731 -0.857863384985533 -0.908393829824336 -0.958924274663139 -0.789047080547085 -0.619169886431032 -0.449292692314979 -0.279415498198926 -0.0453149739694971 0.188785550259932 0.422886074489360 0.656986598718789 0.740079510694937 0.823172422671086 0.906265334647234 0.989358246623382 0.845048306277975 0.700738365932569 0.556428425587163 0.412118485241757 0.173083586208975 -0.0659513128238066 -0.304986211856588 -0.544021110889370]")]
    [RowTest]
    public void TestInterp1(string x, string y, string xi, string expected)
    {
      Check.Array(Vector.ParseMatlabString(expected), Matlab.interp1(Vector.ParseMatlabString(x), Vector.ParseMatlabString(y), Vector.ParseMatlabString(xi)), 1e-12);
    }

    /// <summary>
    /// Check the implementaion of FIR and IIR filter
    /// 
    /// The filter function is in two implementation, one which handle FIR filter only and and other which can handle both FIR and IIR.
    /// All the expected result are created in matlab, see the e.g. below.
    ///   <c>data = [1:0.2:4]';</c>
    ///   <c>windowSize = 5;</c>
    ///   <c>filter(ones(1,windowSize)/windowSize,1,data)</c>
    ///   
    /// <list type="bullet">
    /// <item>Test FIR only function, for 3 coefficients and a inout data of 16 elements.</item>
    /// <item>Test FIR functionality works for the same set of input vector in the FIR/IRR function.</item>
    /// <item>Test IIR function for for  3 FIR coeff and 2 IIR coeff, with the same input data.</item>
    /// </list>
    /// </summary>
    [Test]
    public void Matlab_filter()
    {
      Vector data = Matlab.linspace(1, 4, 16);
      int windowSize = 5;
      Vector r = Matlab.filter(Matlab.ones(windowSize) / windowSize, 1, data);
      Vector e = new double[] { 0.2, 0.44, 0.72, 1.04, 1.4, 1.6, 1.8, 2, 2.2, 2.4, 2.6, 2.8, 3.0, 3.2, 3.4, 3.6 };
      Check.Array(e, r, 1e-12, "#C01");

      r = Matlab.filter(Matlab.ones(windowSize) / windowSize, new double[] { 1 }, data);
      Check.Array(e, r, 1e-12, "#C02");

      r = Matlab.filter(Matlab.ones(windowSize) / windowSize, new double[] { 1, 0.3 }, data);
      e = new double[] { 0.2, 0.38, 0.606, 0.8582, 1.14254, 1.257238, 1.4228286, 1.57315142, 1.728054574, 1.8815836278, 2.03552491166, 2.189342526502, 2.34319724204940, 2.49704082738518, 2.65088775178445, 2.80473367446467 };
      Check.Array(e, r, 1e-12, "#C03");
    }

    private void ComplexAssert(ComplexVector e, ComplexVector r, double delta)
    {
      Assert.AreEqual(e.Length, r.Length);
      for (int i = 0; i < e.Length; i++)
      {
        Assert.AreEqual(e[i].Real, r[i].Real, delta, "Real part is not the same at #" + i);
        Assert.AreEqual(e[i].Imag, r[i].Imag, delta, "Real part is not the same at #" + i);
      }
    }

    [Row(new double[] { 1, 2, 3 }, new double[] { 3, 2, 1 })]
    [Row(new double[] { 1, 2, 3, -4.2 }, new double[] { -4.2, 3, 2, 1 })]
    [Row(new double[] { -4.3 }, new double[] { -4.3 })]
    [RowTest]
    public void Testfliplr(double[] Input, double[] Expected)
    {
      ArrayAssert.AreEqual(Expected, Matlab.fliplr(Input), 0);
    }

    [Row(new double[] { 2, 3 }, new double[] { 4, 5 }, new double[] { 8, 22, 15 })]
    [Row(new double[] { -2 }, new double[] { 4, 5 }, new double[] { -8, -10 })]
    [Row(new double[] { 2, 3 }, new double[] { -4 }, new double[] { -8, -12 })]
    [Row(new double[] { 2, 3, 4 }, new double[] { -4, 3 }, new double[] { -8, -6, -7, 12 })]
    [Row(new double[] { 1, 0.447784423828125 }, new double[] { 1, 1.11938476562500, 0.500366210937500 }, new double[] { 1, 1.56716918945313, 1.00160927325487, 0.224056195467711 })]
    [Row(new double[] { 1, 0.447784423828125 }, new double[] { 0.500366210937500, 1.11938476562500, 1 }, new double[] { 0.500366210937500, 1.34344096109271, 1.50124306231737, 0.447784423828125 })]
    [RowTest]
    public void Testconv(double[] a, double[] b, double[] e)
    {
      ArrayAssert.AreEqual(e, Matlab.conv(a, b), 1e-12);
    }


    [Row(new double[] { 5, 6 }, new double[] { 3, -4 }, 4, new double[] { -11, -1.29700416556564, -0.36, -0.180740641556019 }, new double[] { 0, -3.34644344844872, -1.52, -0.640211994442790 })]
    [RowTest]
    public void TestFreqz(double[] b, double[] a, int N, double[] eReal, double[] eImag)
    {
      ComplexVector e = ComplexVector.Create(eReal, eImag);
      ComplexVector r = Matlab.freqz(b, a, N);
      ComplexAssert(e, r, Math.Pow(10, -14));
    }

    [Row("[1 2 3 2i 1 4i]", "[1 2 3 2 3 0]", 4, 5, "[1.078498867932070,0.886961075796792,0.049909571189807,-0.818104501885229,-1.100956017341277]")]
    [RowTest]
    public void TestInvfreqz(string a, string b, int n, int m, string expected)
    {

      Check.Array(Vector.ParseMatlabString(expected), Matlab.invfreqz(ComplexVector.ParseMatlabString(a), Vector.ParseMatlabString(b), 4, 5), 1e-12);
    }

    [Row(new double[] { 5, 6 }, 3, 4, new double[] { 3.66666666666667, 0, 3.080880229039762, -1.414213562373095, 1.666666666666667, -2.000000000000000, 0.252453104293572, -1.414213562373095 })]
    [Row(new double[] { -0.5, 0.2, 0.4 }, 0.33, 8, new double[] { 0.303030303030303, +0.00000000000000, -0.0981253970397684, -1.08902848165951, -1.08660195079603, -1.64067077647670, -2.14032129091394, -1.41702611811175, -2.72727272727273, -0.606060606060606, -2.60417999681102, +0.297172139310187, -1.94370107950700, +0.783571647765729, -1.21797937584133, +0.625169775762428 })]
    [RowTest]
    public void TestFreqz(double[] b, double a, int N, double[] ev)
    {
      ComplexVector e = ComplexCreate(ev);
      ComplexVector r = Matlab.freqz(b, a, N);
      ComplexAssert(e, r, Math.Pow(10, -14));
    }



    [Row(new double[] { 5, 6 }, 3, 4, new double[] { 3.66666666666667, 0.00000000000000, 3.55658055929614, -0.654389393592305, 3.23844118822056, -1.23673960613947, 2.74727127840295, -1.68294196961579 })]
    [Row(new double[] { -0.5, 0.2, 0.4 }, 0.33, 8, new double[] { 0.303030303030303, +0.00000000000000, 0.247717831921485, -0.427913596385869, 0.0858903078438726, -0.826370472024166, -0.170448190894120, -1.16819550623425, -0.502349922389472, -1.43059396317641, -0.885422338658559, -1.59689942419562, -1.29175451161192, -1.65783118961599, -1.69211598013706, -1.61216111421773 })]
    [RowTest]
    public void TestFreqz_f(double[] b, double a, int N, double[] ev)
    {
      Vector f = Matlab.linspace(0, 1, N);
      ComplexVector e = ComplexCreate(ev);
      ComplexVector r = Matlab.freqz(b, a, f);
      ComplexAssert(e, r, Math.Pow(10, -10));
    }
    [Row("[5 6]", "[7 8]", 4, new double[] { 0.733333333333333, +0.00000000000000, 0.733366870326298, -0.00299032998081517, 0.733475351312866, -0.00615234037599861, 0.733686579042350, -0.00969917899653211 })]
    [Row("[-0.5 0.2 0.4]", "[0.33 -0.13]", 8, new double[] { 0.500000000000000, 0.00000000000000, 0.338700316698319, -0.732550813690233, -0.0959917852285690, -1.31137036465143, -0.685463025426147, -1.64562481918289, -1.30094682423779, -1.72500762353088, -1.84672719399328, -1.59510757548335, -2.27129391293437, -1.32244249602587, -2.55843686258055, -0.970672689284724 })]
    [Row("[5 -7]", "[7 8 3]", 6, "[-0.111111111111111 -0.115233492627810+0.060948287605805i -0.127854016554222+0.124704848681025i -0.149754128528529+0.194510137113111i -0.182302677666316+0.274595161074354i -0.227529066387355+0.371049973765419i]")]
    [RowTest]
    public void TestFreqz_f(string b, string a, int N, object expected)
    {
      ComplexVector e;
      if (expected.GetType() == typeof(double[]))
      {
        e = ComplexCreate((double[])expected);
      }
      else
      {
        e = ComplexVector.ParseMatlabString((string)expected);
      }

      ComplexVector r = Matlab.freqz(Vector.ParseMatlabString(b), Vector.ParseMatlabString(a), Matlab.linspace(0, 1, N));
      ComplexAssert(e, r, 1e-9);
    }



    [Row(new double[] { 3, 4 }, new double[] { 4, 6, 7, 8 }, new double[] { 16, 18, 25, 24 })]
    [Row(new double[] { 0.3, 0.4, -0.5, -0.6 }, new double[] { 0.4, 0.6, 0.7, -0.8 }, new double[] { -0.9904, -0.0864, -1.3103, -0.2472 })]
    [RowTest]
    public void Testpolyval(double[] a, double[] b, double[] e)
    {
      ComplexAssert(ComplexCreate(e), Matlab.polyval(a, ComplexCreate(b)), Math.Pow(10, -10));
    }

    [Row("[2]", 2, "[4]")]
    [Row("[0.3 -4]", 2, "[0.09 16]")]
    [Row("[0.3 -4]", 1, "[0.3 -4]")]
    [Row("[0.3]", 0, "[1]")]
    [RowTest]
    public void TestPow(string input, int pow, string expected)
    {
      Check.Array(Vector.ParseMatlabString(expected), Matlab.pow(Vector.ParseMatlabString(input), pow), 1e-12, "");
    }

    [Row("[1]", 1)]
    [Row("[0 -0.3]", -0.15)]
    [Row("[6 -0.3]", 2.85)]
    [RowTest]
    public void TestMean(string input, double expected)
    {
      Assert.AreEqual(expected, Matlab.mean(Vector.ParseMatlabString(input)));
    }

    [Row(3, "[1 0 0;0 1 0;0 0 1]")]
    [Row(2, "[1 0;0 1]")]
    [Row(1, "[1]")]
    [RowTest]
    public void TestEye(int input, string expected)
    {
      Check.Array(Matrix.ParseMatlabString(expected), Matlab.eye(input), 0);
    }

    [Row("[1]", "[1]")]
    [Row("[1 -2]", "[1;-2]")]
    [Row("[1 -2 3]", "[1;-2;3]")]
    [Row("[1 -2 4+3i]", "[1;-2;4-3i]")]
    [Row("[i]", "[-i]")]
    [RowTest]
    public void TestTranspose(string input, string expected)
    {
      if (input.IndexOf('i') >= 0)
      {
        Check.Array(ComplexMatrix.ParseMatlabString(expected), Matlab.transpose(ComplexVector.ParseMatlabString(input)), 0);
      }
      else
      {
        Check.Array(Matrix.ParseMatlabString(expected), Matlab.transpose(Vector.ParseMatlabString(input)), 0);
      }
    }


    [Row(new double[] { 1, 2 }, new double[] { 1, 2 }, true)]
    [Row(new double[] { 1, 2 }, new double[] { 1, 2.1 }, false)]
    [Row(new double[] { 1, 2 }, new double[] { 1 }, false)]
    [Row(new double[] { 7.1 }, new double[] { 7.1 }, true)]
    [Row(new double[] { 1 }, (int)1, false)]
    [Row(new double[] { 1.1 }, (double)1.1, false)]
    [RowTest]
    public void TestEqual(double[] inp, object o, bool expected)
    {
      if (o.GetType() == typeof(double[]))
        o = new Vector((double[])o);
      Vector a = new Vector(inp);
      Assert.AreEqual(expected, a.Equals(o));
    }
    [Row(new double[] { 1, 2 }, new double[] { 1, 2 }, true)]
    [Row(new double[] { 12 }, new double[] { 12 }, true)]
    [Row(new double[] { 12 }, new double[] { 5 }, false)]
    [Row(new double[] { 7 }, new double[] { 7, 1 }, false)]
    [Row(new double[] { 7, 1 }, new double[] { 7 }, false)]
    [RowTest]
    public void TestEqual(double[] inp, double[] inp1, bool expected)
    {
      Vector a = new Vector(inp);
      Vector b = new Vector(inp1);
      Assert.AreEqual(expected, a == b);
      Assert.AreEqual(!expected, a != b);
    }

    [Row(new double[] { 2, 3, -5, 0, 0 }, new double[] { 0, 0, -2.5, 1 }, new double[] { 0, 0, 0, 0 })]
    [Row(new double[] { 2, 3, -5, 0 }, new double[] { 0, -2.5, 1 }, new double[] { 0, 0, 0 })]
    [Row(new double[] { 2, 3, -5 }, new double[] { -2.5, 1 }, new double[] { 0, 0 })]
    [Row(new double[] { 1.0000000000000000, -0.88132178716326381, 1.9446849990231512, -1.5411758353614124, 1.9990000000000001, -1.4330591234759504, 1.2311240366628613, -0.79858203279946993, 0.40497904522395983, -0.22211326029835751, 0.088151907267356680, -0.070453145466497738, 0.036182127551727200 },
         new double[] { -0.464852844236638, -0.464852844236638, -0.418736669779112, -0.418736669779112, -0.0534140177953053, -0.0534140177953053, 0.301254085765647, 0.301254085765647, 0.510646250974406, 0.510646250974406, 0.565764088652636, 0.565764088652636, },
         new double[] { 0.777087655495174, -0.777087655495174, 0.405973087743377, -0.405973087743377, 0.895237965602180, -0.895237965602180, 0.749059626665794, -0.749059626665794, 0.688897810439431, -0.688897810439431, 0.128079242747487, -0.128079242747487 })]
    [RowTest]
    public void TestRoots(double[] v, double[] refReal, double[] refImag)
    {
      DateTime s = DateTime.Now;
      Vector v1 = v;
      ComplexVector cv = Matlab.roots(v1);
      TimeSpan d = DateTime.Now.Subtract(s);
      double[] Real = Matlab.real(cv);
      double[] Imag = Matlab.imag(cv);
      ArrayAssert.AreEqual(refReal, Real, 1e-14);
      ArrayAssert.AreEqual(refImag, Imag, 1e-14);
    }

    [Row("[2 3]", 2, 1, "[2;3]")]
    [Row("[2 3 4 5 6 7]", 2, 3, "[2 3 4;5 6 7]")]
    [Row("[2 3 4 5 6 7]", 3, 2, "[2 3;4 5; 6 7]")]
    [Row(null, 3, 2, null)]
    [RowTest]
    public void TestReshape(string input, int row, int col, string expected)
    {
      Check.Array(Matrix.ParseMatlabString(expected), Matlab.reshape(Vector.ParseMatlabString(input), row, col), 0);
    }

    [Row("[2 3 4 -5 6 7]", "[2i 3i 4i -5i 6i 7i]")]
    [RowTest]
    public void TestReal2Imag(string input, string expected)
    {
      Check.Array(ComplexVector.ParseMatlabString(expected), Matlab.real2imag(Vector.ParseMatlabString(input)), 0);
    }


    [Test]
    public void TestCholesky()
    {

      Matrix A = Matrix.Random(253, 253);
      Matrix B = Matrix.Random(253, 253);
      Matrix C = new Matrix(B.CopyToArray());
      B.Transpose();
      B = B * C;
      DateTime s = DateTime.Now;
      CholeskyDecomposition Chol = B.CholeskyDecomposition;
      Matrix R = Chol.Solve(A);
      TimeSpan d = DateTime.Now.Subtract(s);
      //Assert.AreEqual(0, d.TotalMilliseconds);

      //TimeSpan d1;
      //Matrix R1 = Matlab.chols(B, A,out d1);      
      //Assert.AreEqual(d.TotalMilliseconds, d1.TotalMilliseconds);
      //CollectionAssert.AreEqual(R.GetComponenets(), R1.GetComponenets()); 
    }

    /// <summary>
    /// Test complex reshape of vectors to matrix
    /// </summary>
    /// <param name="length">Vector</param>
    /// <param name="row">Row of output matrix</param>
    /// <param name="col">Column of output matrix</param>
    [Row(6, 2, 1, ExpectedException = typeof(ArgumentException))]
    [Row(6, 2, 3)]
    [Row(8, 4, 2)]
    [Row(10, 1, 10)]
    [Row(10, 10, 1)]
    [RowTest]
    public void TestReshape(int length, int row, int col)
    {
      ComplexVector cv = RandomComplexVector(length);
      ComplexMatrix cm = Matlab.reshape(cv, row, col);
      Assert.AreEqual(row, cm.RowCount);
      Assert.AreEqual(col, cm.ColumnCount);
      ComplexVector cv1 = cm.GetRowVector(0);
      CollectionAssert.AreEqual((double[])cv[slice.init(0, col, 1)].Real(), (double[])cv1.Real());
    }
    [Test]
    public void TestReshape()
    {
      ComplexVector cv = null;
      Assert.IsNull(Matlab.reshape(cv, 1, 1));
    }

    /// <summary>
    /// Test inplace multiplcation of complex matrix and complex vector
    /// </summary>
    /// <param name="row">Matrix row</param>
    /// <param name="col">Matrix column</param>
    /// <param name="length">Vector length</param>
    [Row(4, 4, 4)]
    [Row(4, 3, 4)]
    [Row(3, 1, 3)]
    [Row(4, 3, 3)]
    [RowTest]
    public void TestComplexMultiplyWithVector(int row, int col, int length)
    {
      //Expected .* (v*ones(1,size))      
      ComplexMatrix Expected = ComplexMatrix.Random(row, col, new StandardDistribution());
      ComplexMatrix Actual = new ComplexMatrix(Expected);
      ComplexMatrix v = ComplexMatrix.Random(length, 1, new StandardDistribution());
      if (row == length)
      {
        Matrix One = Matrix.Ones(1, col);
        ComplexMatrix m1 = v * One;
        Expected.ArrayMultiply(m1);
      }
      else
      {
        Matrix One = Matrix.Ones(1, row);
        ComplexMatrix m1 = v * One;
        ComplexMatrix m2 = m1.Transpose();
        Expected.ArrayMultiply(m2);
      }

      Actual.MultiplyInplace(v.GetColumnVector(0));
      CheckComplexMatrix(Expected, Actual);
    }

    private void CheckMatrix(Matrix expected, Matrix actual)
    {
      Assert.AreEqual(expected.RowCount, actual.RowCount);
      Assert.AreEqual(expected.ColumnCount, actual.ColumnCount);
      for (int i = 0; i < expected.RowCount; ++i)
      {
        for (int j = 0; j < expected.ColumnCount; ++j)
        {
          Assert.AreEqual(expected[i, j], actual[i, j]);
        }
      }

    }
    private void CheckComplexMatrix(ComplexMatrix expected, ComplexMatrix actual)
    {
      Assert.AreEqual(expected.RowCount, actual.RowCount);
      Assert.AreEqual(expected.ColumnCount, actual.ColumnCount);
      for (int i = 0; i < expected.RowCount; ++i)
      {
        for (int j = 0; j < expected.ColumnCount; ++j)
        {
          Assert.AreEqual(expected[i, j].Real, actual[i, j].Real);
          Assert.AreEqual(expected[i, j].Imag, actual[i, j].Imag);
        }
      }

    }

    private ComplexMatrix RandomComplexMatrix(int row, int col)
    {
      return ComplexMatrix.Random(row, col, new StandardDistribution());
    }
    private ComplexVector RandomComplexVector(int length)
    {
      Complex[] cv = new Complex[length];
      Random r = new Random(2);
      for (int i = 0; i < cv.Length; ++i)
      {
        cv[i] = new Complex(r.NextDouble(), r.NextDouble());
      }
      return new ComplexVector(cv);
    }

    [Row(new double[] { 4, -2, -7, 6 }, new double[] { 1, 0, 3, -4, -16, 38 })]
    [Row(new double[] { 4, -3 }, new double[] { 1, 0, -4, 3 })]
    [Row(new double[] { 4, -0.4 }, new double[] { 1, 0, -4, 0.4 })]
    [RowTest]
    public void TestPoly(double[] input, double[] expected)
    {
      int[] real = slice.init(0, input.Length / 2, 2);
      int[] imag = slice.init(1, input.Length / 2, 2);
      Vector inp = input;
      ComplexVector complexVectorCreate = ComplexVector.Create(inp[real], inp[imag]);
      real = slice.init(0, expected.Length / 2, 2);
      imag = slice.init(1, expected.Length / 2, 2);
      Vector exp = expected;
      ComplexVector complexVectorExpected = ComplexVector.Create(exp[real], exp[imag]);
      Check.Array(complexVectorExpected.Real(), Matlab.poly(complexVectorCreate).Real(), 1e-12, "");
      Check.Array(complexVectorExpected.Imag(), Matlab.poly(complexVectorCreate).Imag(), 1e-12, "");
    }

    [Row(new double[] { 0, 1, 2 }, new double[] { 1, 1, 1 })]
    [Row(new double[] { -0.1 }, new double[] { -1 })]
    [Row(new double[] { 0, -1, 2 }, new double[] { 1, -1, 1 })]
    [Row(new double[] { 0, -1, -2 }, new double[] { 1, -1, -1 })]
    [Row(new double[] { -4, 2, -3 }, new double[] { -1, 1, -1 })]
    [RowTest]
    public void TestSign(double[] input, double[] expected)
    {
      Check.Array(expected, Matlab.sign(input), 0, "");
    }

    [Row(0, 1, "i")]
    [Row(0, -1, "-i")]
    [Row(1, 0, "1")]
    [Row(-1, 0, "-1")]
    [Row(1, 1, "1+i")]
    [Row(1, -1, "1-i")]
    [Row(-1, 1, "-1+i")]
    [Row(-1, -1, "-1-i")]
    [Row(2.2, 2.1, "2.2+2.1i")]
    [Row(2.2, -2.1, "2.2-2.1i")]
    [Row(-2.2, 2.1, "-2.2+2.1i")]
    [Row(-2.2, -2.1, "-2.2-2.1i")]
    [RowTest]
    public void TestToMatlabString(double real, double imag, string expected)
    {
      Assert.AreEqual(expected, (new Complex(real, imag)).ToMatlabString());
    }

    [Row("[4 3 2 1]", new double[] { 4, 3, 2, 1 })]
    [Row(" [ 4  3 2 1  ]  ", new double[] { 4, 3, 2, 1 })]
    [Row("[4.32]  ", new double[] { 4.32 })]
    [Row("[-7.32 -3 2]  ", new double[] { -7.32, -3, 2 })]
    [Row("-7.32 -3 2]", new double[] { 1 }, ExpectedException = typeof(FormatException))]
    [Row("[-7.32 -3 2  ", new double[] { 1 }, ExpectedException = typeof(FormatException))]
    [Row("-7.32 -3 2  ", new double[] { 1 }, ExpectedException = typeof(FormatException))]
    [Row("[4.1232 3]", new double[] { 4.1232, 3 })]
    [Row("[4.32e-4 -3]", new double[] { 4.32e-4, -3 })]
    [RowTest]
    public void TestParseMatlabString(string vectorString, double[] expected)
    {
      CollectionAssert.AreEqual(expected, (double[])Vector.ParseMatlabString(vectorString));
    }

    [Row("[4.32 3]", "[[4.32,3]]")]
    [Row("[4.33;4]", "[[4.33] [4]]")]
    [Row("[4.33 10;4 11]", "[[4.33,10] [4,11]]")]
    [Row("[4.32e-4 -3]", "[[0.000432,-3]]")]
    [Row("[i]", "[[I]]")]
    [Row("[3i]", "[[I*3]]")]
    [Row("[6+3i]", "[[6+I*3]]")]
    [Row("[6-3i]", "[[6-I*3]]")]
    [Row("[-4-3i]", "[[-4-I*3]]")]
    [Row("[-4-3i;5-i]", "[[-4-I*3] [5-I]]")]
    [Row("[ -4-3i ; 5-i ]", "[[-4-I*3] [5-I]]")]
    [Row("[Inf]", "[[Infinity]]")]
    [Row("[NaN]", "[[NaN]]")]
    [Row("[4.33,10;4,1-i]", "[[4.33,10] [4,1-I]]")]
    [RowTest]
    public void TestParseMatlabString(string matrixString, string expected)
    {
      Assert.AreEqual(expected, (ComplexMatrix.ParseMatlabString(matrixString)).ToString(CultureInfo.InvariantCulture));
    }

    [Row("[-4-3i]", new double[] { -4, -3 })]
    [Row("[ -4-3i  5-i ]", new double[] { -4, -3, 5, -1 })]
    [Row("[4.33,10]", new double[] { 4.33, 0, 10, 0 })]
    [RowTest]
    public void TestParseMatlabStringVector(string vectorString, double[] expected)
    {
      ComplexVector cv = ComplexCreate(expected);
      Check.Array(cv, ComplexVector.ParseMatlabString(vectorString), 0);
    }

    [Row(new double[] { double.PositiveInfinity }, "[Inf]")]
    [Row(new double[] { double.NegativeInfinity }, "[-Inf]")]
    [Row(new double[] { double.PositiveInfinity, 1 }, "[Inf 1]")]
    [Row(new double[] { double.PositiveInfinity, 0.1 }, "[Inf 0.1]")]
    [Row(new double[] { -0.1, double.NegativeInfinity, 0.1 }, "[-0.1 -Inf 0.1]")]
    [Row(new double[] { -0.1, double.NaN }, "[-0.1 NaN]")]
    [RowTest]
    public void TestToMatlabString(double[] v, string expected)
    {
      Assert.AreEqual(expected, ((Vector)v).ToMatlabString());
    }

    [Row("[32.7105157354328 33.1547187386686 32.0325745916242 34.6664341039486 30.2267469984957 30.0617466626863 29.5805447271662 28.7479833889642 25.7097374007302 24.1701946318586 22.7286469477547 20.6932541705020 19.0394245237871 16.1989013323171 13.0317582178894 11.0610577178881 9.01661917455581 7.98087389166783 8.24859453776086 9.10291011987251 9.50112994627473 9.53280775506780 12.9775618880676 12.1114573996491 12.3740825972859 14.3574402956622 12.4452239609397 13.1735720623063 12.7178128802229 13.1034877542879 12.0613371502178 11.9103108543606 9.72883731478129 8.65179968833510 8.71970053200567 7.53681960297342 7.56983354360543 9.66200020788330 9.73182070358818 11.2022261847376 13.9970181216206 13.7156335711490 15.8649308247322 17.9673110455167 18.3643678093966 16.6340438962676 18.2120119799707 17.1234417855058 16.8136055153384 17.0979119960461 17.1217410685973 19.2100373789941 16.7632281683257 14.1280673034273 18.6181869629220 14.8519200401986 14.1223090691609 13.0511020610012 15.3675714660903 15.4710399886928 18.3418437760474 18.3477634048742 21.5564824607085 21.3971906973554 24.5104443911703 24.5195374033171 26.0168585082576 27.2887121702646 25.5053269527029 25.7027987123988 29.6230999047318 30.6759108660079 36.6978049949790 30.1621865577320 28.9025139540731 27.5890128444768 28.2661469225298 29.5822897826372 27.4309458855101 27.8970690939112 27.9810955176073 28.4455035091532 28.5427365754585 29.9774863149186 29.3161798166468 34.2298366613265 31.5172807535531 37.1007197046858 35.3479108889837 34.9574415521256 32.6692320208746 27.7005528750736 35.0254870095754 31.0244370601748 23.2899262699437 24.6780270349062 23.5901759141402 24.0524235703604 23.0119016537830 21.3270290928561 22.4884922622169]",
          5, new int[] { 3, 25, 44, 51, 72, 87 })]
    [Row("[32.7105157354328 33.1547187386686 32.0325745916242 34.6664341039486 30.2267469984957 30.0617466626863 29.5805447271662 28.7479833889642 25.7097374007302 24.1701946318586 22.7286469477547 20.6932541705020 19.0394245237871 16.1989013323171 13.0317582178894 11.0610577178881 9.01661917455581 7.98087389166783 8.24859453776086 9.10291011987251 9.50112994627473 9.53280775506780 12.9775618880676 12.1114573996491 12.3740825972859 14.3574402956622 12.4452239609397 13.1735720623063 12.7178128802229 13.1034877542879 12.0613371502178 11.9103108543606 9.72883731478129 8.65179968833510 8.71970053200567 7.53681960297342 7.56983354360543 9.66200020788330 9.73182070358818 11.2022261847376 13.9970181216206 13.7156335711490 15.8649308247322 17.9673110455167 18.3643678093966 16.6340438962676 18.2120119799707 17.1234417855058 16.8136055153384 17.0979119960461 17.1217410685973 19.2100373789941 16.7632281683257 14.1280673034273 18.6181869629220 14.8519200401986 14.1223090691609 13.0511020610012 15.3675714660903 15.4710399886928 18.3418437760474 18.3477634048742 21.5564824607085 21.3971906973554 24.5104443911703 24.5195374033171 26.0168585082576 27.2887121702646 25.5053269527029 25.7027987123988 29.6230999047318 30.6759108660079 36.6978049949790 30.1621865577320 28.9025139540731 27.5890128444768 28.2661469225298 29.5822897826372 27.4309458855101 27.8970690939112 27.9810955176073 28.4455035091532 28.5427365754585 29.9774863149186 29.3161798166468 34.2298366613265 31.5172807535531 37.1007197046858 35.3479108889837 34.9574415521256 32.6692320208746 27.7005528750736 35.0254870095754 31.0244370601748 23.2899262699437 24.6780270349062 23.5901759141402 24.0524235703604 23.0119016537830 21.3270290928561 22.4884922622169]",
          2, new int[] { 3, 22, 25, 44, 51, 54, 67, 72, 77, 87, 92 })]
    [Row("[32.7105157354328 33.1547187386686 32.0325745916242 34.6664341039486 30.2267469984957 30.0617466626863 29.5805447271662 28.7479833889642 25.7097374007302 24.1701946318586 22.7286469477547 20.6932541705020 19.0394245237871 16.1989013323171 13.0317582178894 11.0610577178881 9.01661917455581 7.98087389166783 8.24859453776086 9.10291011987251 9.50112994627473 9.53280775506780 12.9775618880676 12.1114573996491 12.3740825972859 14.3574402956622 12.4452239609397 13.1735720623063 12.7178128802229 13.1034877542879 12.0613371502178 11.9103108543606 9.72883731478129 8.65179968833510 8.71970053200567 7.53681960297342 7.56983354360543 9.66200020788330 9.73182070358818 11.2022261847376 13.9970181216206 13.7156335711490 15.8649308247322 17.9673110455167 18.3643678093966 16.6340438962676 18.2120119799707 17.1234417855058 16.8136055153384 17.0979119960461 17.1217410685973 19.2100373789941 16.7632281683257 14.1280673034273 18.6181869629220 14.8519200401986 14.1223090691609 13.0511020610012 15.3675714660903 15.4710399886928 18.3418437760474 18.3477634048742 21.5564824607085 21.3971906973554 24.5104443911703 24.5195374033171 26.0168585082576 27.2887121702646 25.5053269527029 25.7027987123988 29.6230999047318 30.6759108660079 36.6978049949790 30.1621865577320 28.9025139540731 27.5890128444768 28.2661469225298 29.5822897826372 27.4309458855101 27.8970690939112 27.9810955176073 28.4455035091532 28.5427365754585 29.9774863149186 29.3161798166468 34.2298366613265 31.5172807535531 37.1007197046858 35.3479108889837 34.9574415521256 32.6692320208746 27.7005528750736 35.0254870095754 31.0244370601748 23.2899262699437 24.6780270349062 23.5901759141402 24.0524235703604 23.0119016537830 21.3270290928561 22.4884922622169]",
          12, new int[] { 3, 72, 87 })]
    [Row("[-32.7105157354328 -33.1547187386686 -32.0325745916242 -34.6664341039486 -30.2267469984957 -30.0617466626863 -29.5805447271662 -28.7479833889642 -25.7097374007302 -24.1701946318586 -22.7286469477547 -20.6932541705020 -19.0394245237871 -16.1989013323171 -13.0317582178894 -11.0610577178881 -9.01661917455581 -7.98087389166783 -8.24859453776086 -9.10291011987251 -9.50112994627473 -9.53280775506780 -12.9775618880676 -12.1114573996491 -12.3740825972859 -14.3574402956622 -12.4452239609397 -13.1735720623063 -12.7178128802229 -13.1034877542879 -12.0613371502178 -11.9103108543606 -9.72883731478129 -8.65179968833510 -8.71970053200567 -7.53681960297342 -7.56983354360543 -9.66200020788330 -9.73182070358818 -11.2022261847376 -13.9970181216206 -13.7156335711490 -15.8649308247322 -17.9673110455167 -18.3643678093966 -16.6340438962676 -18.2120119799707 -17.1234417855058 -16.8136055153384 -17.0979119960461 -17.1217410685973 -19.2100373789941 -16.7632281683257 -14.1280673034273 -18.6181869629220 -14.8519200401986 -14.1223090691609 -13.0511020610012 -15.3675714660903 -15.4710399886928 -18.3418437760474 -18.3477634048742 -21.5564824607085 -21.3971906973554 -24.5104443911703 -24.5195374033171 -26.0168585082576 -27.2887121702646 -25.5053269527029 -25.7027987123988 -29.6230999047318 -30.6759108660079 -36.6978049949790 -30.1621865577320 -28.9025139540731 -27.5890128444768 -28.2661469225298 -29.5822897826372 -27.4309458855101 -27.8970690939112 -27.9810955176073 -28.4455035091532 -28.5427365754585 -29.9774863149186 -29.3161798166468 -34.2298366613265 -31.5172807535531 -37.1007197046858 -35.3479108889837 -34.9574415521256 -32.6692320208746 -27.7005528750736 -35.0254870095754 -31.0244370601748 -23.2899262699437 -24.6780270349062 -23.5901759141402 -24.0524235703604 -23.0119016537830 -21.3270290928561 -22.4884922622169]",
          2, new int[] { 17, 35, 45, 48, 53, 57, 68, 75, 78, 91, 94, 99 })]
    [RowTest]
    public void TestFindPeaks(string v, int dist, int[] expected)
    {
      Vector vec = Vector.ParseMatlabString(v);
      int[] actual = Matlab.findpeaks(vec, FindPeaks.FindPeakType.MinPeakDistance, dist);
      Check.Array(expected, actual, "");
    }

    [Row("[1 2]","[1]")]
    [Row("[1 2 1.1]", "[1 -0.9]")]
    [Row("[1]", "[]")] 
    [RowTest]
    public void Testdiff(string input, string expected)
    {
      Vector vec = Vector.ParseMatlabString(input);
      Check.Array(Vector.ParseMatlabString(expected), Matlab.diff(vec), 1e-12);
    }
  }
}
